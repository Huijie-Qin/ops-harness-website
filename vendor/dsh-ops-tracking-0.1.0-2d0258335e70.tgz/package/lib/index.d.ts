import { Service, type Context } from '@deepseek-ai/cordis';
import type { HostConnectionHandle } from '@deepseek-ai/dsh-client-connection';
import { TrackingService } from './service.js';
import type { TrackingIdentityProvider } from './identity-provider.js';
import type { EmployeeProvider } from './host.js';
export * from './host.js';
export type { TrackingIdentityProvider } from './identity-provider.js';
export declare const name = "ops-tracking";
export declare const inject: string[];
declare class OpsTracking extends Service {
    readonly tracking: TrackingService;
    constructor(ctx: Context, tracking: TrackingService);
    clearIdentity(manualLogout?: boolean): void;
    forModule(module: string): import("./host.js").ModuleTracker;
    registerIdentityProvider(provider: TrackingIdentityProvider): () => void;
    registerEmployeeProvider(provider: EmployeeProvider): () => void;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        connection: HostConnectionHandle;
        opsTracking: OpsTracking;
    }
}
export declare function apply(ctx: Context, input?: unknown): Promise<void>;
//# sourceMappingURL=index.d.ts.map
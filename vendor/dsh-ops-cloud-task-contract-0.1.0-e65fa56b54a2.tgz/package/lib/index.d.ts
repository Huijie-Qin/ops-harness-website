import { z } from 'zod';
/**
 * Cloud scheduled-task protocol, version 1.
 *
 * Three parties share it: the product Host (submits tasks, reads runs, downloads artifacts),
 * the website control plane (owns task definitions, schedules, runs, artifacts, tokens and
 * instances) and the executor plugin inside each user's cloud instance (claims runs, executes
 * them unattended, uploads results). Every wire shape is a strict zod schema; unknown keys
 * are rejected on both ends so a version drift fails loudly instead of silently.
 */
export declare const CONTRACT_VERSION: 1;
export declare const MAX_TASK_NAME_CHARS = 80;
export declare const MAX_TASK_DESCRIPTION_CHARS = 500;
export declare const MAX_PROMPT_CHARS = 12000;
export declare const MAX_SKILLS = 64;
export declare const MAX_TIMEOUT_MINUTES = 240;
export declare const DEFAULT_TIMEOUT_MINUTES = 30;
export declare const MAX_SUMMARY_CHARS = 2000;
export declare const MAX_ARTIFACT_BYTES: number;
export declare const MAX_ARTIFACT_FILES = 5000;
export declare const MAX_INPUT_BYTES: number;
export declare const RESULT_RETENTION_DAYS = 7;
export declare const MAX_QUEUED_RUNS_PER_USER = 10;
export declare const HEARTBEAT_INTERVAL_MS = 30000;
export declare const CLAIM_LEASE_MS = 120000;
/** WeLink employee id: the identity key shared with the website tracking `users` table (issuer `welink`). */
export declare const EmployeeIdSchema: z.ZodString;
export type EmployeeId = z.infer<typeof EmployeeIdSchema>;
export declare const TaskIdSchema: z.ZodString;
export declare const RunIdSchema: z.ZodString;
export declare const InstanceIdSchema: z.ZodString;
/** Opaque bearer tokens (user access token, executor token). Only the sha256 digest is stored server side. */
export declare const TokenSchema: z.ZodString;
export declare const DateTimeSchema: z.ZodISODateTime;
export declare const Sha256Schema: z.ZodString;
export declare const OnceScheduleSchema: z.ZodObject<{
    kind: z.ZodLiteral<"once">;
    at: z.ZodISODateTime;
}, z.core.$strict>;
export declare const IntervalScheduleSchema: z.ZodObject<{
    kind: z.ZodLiteral<"interval">;
    everyMinutes: z.ZodNumber;
    anchorAt: z.ZodISODateTime;
}, z.core.$strict>;
export declare const calendarFrequencies: readonly ["daily", "weekly", "monthly"];
export declare const CalendarScheduleSchema: z.ZodObject<{
    kind: z.ZodLiteral<"calendar">;
    frequency: z.ZodEnum<{
        daily: "daily";
        weekly: "weekly";
        monthly: "monthly";
    }>;
    time: z.ZodString;
    timeZone: z.ZodString;
    weekdays: z.ZodOptional<z.ZodArray<z.ZodNumber>>;
    dayOfMonth: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
export declare const CloudScheduleSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"once">;
    at: z.ZodISODateTime;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"interval">;
    everyMinutes: z.ZodNumber;
    anchorAt: z.ZodISODateTime;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"calendar">;
    frequency: z.ZodEnum<{
        daily: "daily";
        weekly: "weekly";
        monthly: "monthly";
    }>;
    time: z.ZodString;
    timeZone: z.ZodString;
    weekdays: z.ZodOptional<z.ZodArray<z.ZodNumber>>;
    dayOfMonth: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>], "kind">;
export type CloudSchedule = z.infer<typeof CloudScheduleSchema>;
export declare const SkillNameSchema: z.ZodString;
export declare const CloudTaskDefinitionSchema: z.ZodObject<{
    name: z.ZodString;
    description: z.ZodDefault<z.ZodString>;
    expertId: z.ZodString;
    skillNames: z.ZodDefault<z.ZodArray<z.ZodString>>;
    prompt: z.ZodString;
    schedule: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"once">;
        at: z.ZodISODateTime;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"interval">;
        everyMinutes: z.ZodNumber;
        anchorAt: z.ZodISODateTime;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"calendar">;
        frequency: z.ZodEnum<{
            daily: "daily";
            weekly: "weekly";
            monthly: "monthly";
        }>;
        time: z.ZodString;
        timeZone: z.ZodString;
        weekdays: z.ZodOptional<z.ZodArray<z.ZodNumber>>;
        dayOfMonth: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>], "kind">;
    activeFrom: z.ZodOptional<z.ZodISODateTime>;
    activeUntil: z.ZodOptional<z.ZodISODateTime>;
    timeoutMinutes: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export type CloudTaskDefinition = z.infer<typeof CloudTaskDefinitionSchema>;
export type CloudTaskDefinitionInput = z.input<typeof CloudTaskDefinitionSchema>;
export declare const taskStates: readonly ["scheduled", "paused", "error"];
export declare const TaskStateSchema: z.ZodEnum<{
    error: "error";
    scheduled: "scheduled";
    paused: "paused";
}>;
export type TaskState = z.infer<typeof TaskStateSchema>;
export declare const runStatuses: readonly ["queued", "claimed", "running", "succeeded", "failed", "cancelled", "timed-out", "expired"];
export declare const RunStatusSchema: z.ZodEnum<{
    queued: "queued";
    claimed: "claimed";
    running: "running";
    succeeded: "succeeded";
    failed: "failed";
    cancelled: "cancelled";
    "timed-out": "timed-out";
    expired: "expired";
}>;
export type RunStatus = z.infer<typeof RunStatusSchema>;
export declare const terminalRunStatuses: readonly RunStatus[];
export declare const isTerminalRunStatus: (status: RunStatus) => boolean;
export declare const RunTriggerSchema: z.ZodEnum<{
    schedule: "schedule";
    manual: "manual";
}>;
export declare const ArtifactInfoSchema: z.ZodObject<{
    size: z.ZodNumber;
    sha256: z.ZodString;
    fileCount: z.ZodNumber;
}, z.core.$strict>;
export type ArtifactInfo = z.infer<typeof ArtifactInfoSchema>;
export declare const CloudRunSchema: z.ZodObject<{
    id: z.ZodString;
    taskId: z.ZodString;
    employeeId: z.ZodString;
    taskName: z.ZodString;
    status: z.ZodEnum<{
        queued: "queued";
        claimed: "claimed";
        running: "running";
        succeeded: "succeeded";
        failed: "failed";
        cancelled: "cancelled";
        "timed-out": "timed-out";
        expired: "expired";
    }>;
    trigger: z.ZodEnum<{
        schedule: "schedule";
        manual: "manual";
    }>;
    scheduledAt: z.ZodISODateTime;
    queuedAt: z.ZodISODateTime;
    claimedAt: z.ZodOptional<z.ZodISODateTime>;
    startedAt: z.ZodOptional<z.ZodISODateTime>;
    finishedAt: z.ZodOptional<z.ZodISODateTime>;
    summary: z.ZodDefault<z.ZodString>;
    errorCode: z.ZodDefault<z.ZodString>;
    sessionId: z.ZodOptional<z.ZodString>;
    autoDecisions: z.ZodOptional<z.ZodNumber>;
    artifact: z.ZodOptional<z.ZodObject<{
        size: z.ZodNumber;
        sha256: z.ZodString;
        fileCount: z.ZodNumber;
    }, z.core.$strict>>;
    cancelRequested: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
export type CloudRun = z.infer<typeof CloudRunSchema>;
export declare const CloudTaskSchema: z.ZodObject<{
    name: z.ZodString;
    description: z.ZodDefault<z.ZodString>;
    expertId: z.ZodString;
    skillNames: z.ZodDefault<z.ZodArray<z.ZodString>>;
    prompt: z.ZodString;
    schedule: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"once">;
        at: z.ZodISODateTime;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"interval">;
        everyMinutes: z.ZodNumber;
        anchorAt: z.ZodISODateTime;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"calendar">;
        frequency: z.ZodEnum<{
            daily: "daily";
            weekly: "weekly";
            monthly: "monthly";
        }>;
        time: z.ZodString;
        timeZone: z.ZodString;
        weekdays: z.ZodOptional<z.ZodArray<z.ZodNumber>>;
        dayOfMonth: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>], "kind">;
    activeFrom: z.ZodOptional<z.ZodISODateTime>;
    activeUntil: z.ZodOptional<z.ZodISODateTime>;
    timeoutMinutes: z.ZodDefault<z.ZodNumber>;
    id: z.ZodString;
    employeeId: z.ZodString;
    state: z.ZodEnum<{
        error: "error";
        scheduled: "scheduled";
        paused: "paused";
    }>;
    nextRunAt: z.ZodNullable<z.ZodISODateTime>;
    lastRun: z.ZodOptional<z.ZodObject<{
        id: z.ZodString;
        taskId: z.ZodString;
        employeeId: z.ZodString;
        taskName: z.ZodString;
        status: z.ZodEnum<{
            queued: "queued";
            claimed: "claimed";
            running: "running";
            succeeded: "succeeded";
            failed: "failed";
            cancelled: "cancelled";
            "timed-out": "timed-out";
            expired: "expired";
        }>;
        trigger: z.ZodEnum<{
            schedule: "schedule";
            manual: "manual";
        }>;
        scheduledAt: z.ZodISODateTime;
        queuedAt: z.ZodISODateTime;
        claimedAt: z.ZodOptional<z.ZodISODateTime>;
        startedAt: z.ZodOptional<z.ZodISODateTime>;
        finishedAt: z.ZodOptional<z.ZodISODateTime>;
        summary: z.ZodDefault<z.ZodString>;
        errorCode: z.ZodDefault<z.ZodString>;
        sessionId: z.ZodOptional<z.ZodString>;
        autoDecisions: z.ZodOptional<z.ZodNumber>;
        artifact: z.ZodOptional<z.ZodObject<{
            size: z.ZodNumber;
            sha256: z.ZodString;
            fileCount: z.ZodNumber;
        }, z.core.$strict>>;
        cancelRequested: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>>;
    revision: z.ZodNumber;
    createdAt: z.ZodISODateTime;
    updatedAt: z.ZodISODateTime;
}, z.core.$strict>;
export type CloudTask = z.infer<typeof CloudTaskSchema>;
export declare const ExecutorSkillSchema: z.ZodObject<{
    name: z.ZodString;
    description: z.ZodDefault<z.ZodString>;
}, z.core.$strict>;
export declare const ExecutorExpertSchema: z.ZodObject<{
    id: z.ZodString;
    presetId: z.ZodString;
    name: z.ZodString;
    summary: z.ZodDefault<z.ZodString>;
    available: z.ZodBoolean;
    skills: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        description: z.ZodDefault<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const ExecutorCatalogSchema: z.ZodObject<{
    generatedAt: z.ZodISODateTime;
    defaultExpertId: z.ZodString;
    experts: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        presetId: z.ZodString;
        name: z.ZodString;
        summary: z.ZodDefault<z.ZodString>;
        available: z.ZodBoolean;
        skills: z.ZodArray<z.ZodObject<{
            name: z.ZodString;
            description: z.ZodDefault<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ExecutorCatalog = z.infer<typeof ExecutorCatalogSchema>;
export declare const instanceStates: readonly ["stopped", "starting", "running", "stopping", "error"];
export declare const InstanceStateSchema: z.ZodEnum<{
    error: "error";
    running: "running";
    stopped: "stopped";
    starting: "starting";
    stopping: "stopping";
}>;
export type InstanceState = z.infer<typeof InstanceStateSchema>;
export declare const InstanceStatusSchema: z.ZodObject<{
    state: z.ZodEnum<{
        error: "error";
        running: "running";
        stopped: "stopped";
        starting: "starting";
        stopping: "stopping";
    }>;
    updatedAt: z.ZodISODateTime;
    lastHeartbeatAt: z.ZodOptional<z.ZodISODateTime>;
    bundleVersion: z.ZodOptional<z.ZodString>;
    dshVersion: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type InstanceStatus = z.infer<typeof InstanceStatusSchema>;
export declare const MeResponseSchema: z.ZodObject<{
    contractVersion: z.ZodLiteral<1>;
    employeeId: z.ZodString;
    displayName: z.ZodDefault<z.ZodString>;
    instance: z.ZodObject<{
        state: z.ZodEnum<{
            error: "error";
            running: "running";
            stopped: "stopped";
            starting: "starting";
            stopping: "stopping";
        }>;
        updatedAt: z.ZodISODateTime;
        lastHeartbeatAt: z.ZodOptional<z.ZodISODateTime>;
        bundleVersion: z.ZodOptional<z.ZodString>;
        dshVersion: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
}, z.core.$strict>;
/**
 * Artifact transfer headers (both directions). Upload: `PUT executorArtifact(runId)` with
 * `content-type: application/zip` or `application/octet-stream`, the sha256 header (required)
 * and the file-count header (optional, default 0). Download: the same headers on the response.
 * A `DELETE task` and an empty `claim` answer 204 with no body.
 */
export declare const ARTIFACT_SHA256_HEADER: "x-artifact-sha256";
export declare const ARTIFACT_FILE_COUNT_HEADER: "x-artifact-file-count";
export type MeResponse = z.infer<typeof MeResponseSchema>;
export declare const CatalogResponseSchema: z.ZodObject<{
    catalog: z.ZodNullable<z.ZodObject<{
        generatedAt: z.ZodISODateTime;
        defaultExpertId: z.ZodString;
        experts: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            presetId: z.ZodString;
            name: z.ZodString;
            summary: z.ZodDefault<z.ZodString>;
            available: z.ZodBoolean;
            skills: z.ZodArray<z.ZodObject<{
                name: z.ZodString;
                description: z.ZodDefault<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    stale: z.ZodBoolean;
}, z.core.$strict>;
export type CatalogResponse = z.infer<typeof CatalogResponseSchema>;
export declare const TaskListResponseSchema: z.ZodObject<{
    tasks: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        description: z.ZodDefault<z.ZodString>;
        expertId: z.ZodString;
        skillNames: z.ZodDefault<z.ZodArray<z.ZodString>>;
        prompt: z.ZodString;
        schedule: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"once">;
            at: z.ZodISODateTime;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"interval">;
            everyMinutes: z.ZodNumber;
            anchorAt: z.ZodISODateTime;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"calendar">;
            frequency: z.ZodEnum<{
                daily: "daily";
                weekly: "weekly";
                monthly: "monthly";
            }>;
            time: z.ZodString;
            timeZone: z.ZodString;
            weekdays: z.ZodOptional<z.ZodArray<z.ZodNumber>>;
            dayOfMonth: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>], "kind">;
        activeFrom: z.ZodOptional<z.ZodISODateTime>;
        activeUntil: z.ZodOptional<z.ZodISODateTime>;
        timeoutMinutes: z.ZodDefault<z.ZodNumber>;
        id: z.ZodString;
        employeeId: z.ZodString;
        state: z.ZodEnum<{
            error: "error";
            scheduled: "scheduled";
            paused: "paused";
        }>;
        nextRunAt: z.ZodNullable<z.ZodISODateTime>;
        lastRun: z.ZodOptional<z.ZodObject<{
            id: z.ZodString;
            taskId: z.ZodString;
            employeeId: z.ZodString;
            taskName: z.ZodString;
            status: z.ZodEnum<{
                queued: "queued";
                claimed: "claimed";
                running: "running";
                succeeded: "succeeded";
                failed: "failed";
                cancelled: "cancelled";
                "timed-out": "timed-out";
                expired: "expired";
            }>;
            trigger: z.ZodEnum<{
                schedule: "schedule";
                manual: "manual";
            }>;
            scheduledAt: z.ZodISODateTime;
            queuedAt: z.ZodISODateTime;
            claimedAt: z.ZodOptional<z.ZodISODateTime>;
            startedAt: z.ZodOptional<z.ZodISODateTime>;
            finishedAt: z.ZodOptional<z.ZodISODateTime>;
            summary: z.ZodDefault<z.ZodString>;
            errorCode: z.ZodDefault<z.ZodString>;
            sessionId: z.ZodOptional<z.ZodString>;
            autoDecisions: z.ZodOptional<z.ZodNumber>;
            artifact: z.ZodOptional<z.ZodObject<{
                size: z.ZodNumber;
                sha256: z.ZodString;
                fileCount: z.ZodNumber;
            }, z.core.$strict>>;
            cancelRequested: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strict>>;
        revision: z.ZodNumber;
        createdAt: z.ZodISODateTime;
        updatedAt: z.ZodISODateTime;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const TaskResponseSchema: z.ZodObject<{
    task: z.ZodObject<{
        name: z.ZodString;
        description: z.ZodDefault<z.ZodString>;
        expertId: z.ZodString;
        skillNames: z.ZodDefault<z.ZodArray<z.ZodString>>;
        prompt: z.ZodString;
        schedule: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"once">;
            at: z.ZodISODateTime;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"interval">;
            everyMinutes: z.ZodNumber;
            anchorAt: z.ZodISODateTime;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"calendar">;
            frequency: z.ZodEnum<{
                daily: "daily";
                weekly: "weekly";
                monthly: "monthly";
            }>;
            time: z.ZodString;
            timeZone: z.ZodString;
            weekdays: z.ZodOptional<z.ZodArray<z.ZodNumber>>;
            dayOfMonth: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>], "kind">;
        activeFrom: z.ZodOptional<z.ZodISODateTime>;
        activeUntil: z.ZodOptional<z.ZodISODateTime>;
        timeoutMinutes: z.ZodDefault<z.ZodNumber>;
        id: z.ZodString;
        employeeId: z.ZodString;
        state: z.ZodEnum<{
            error: "error";
            scheduled: "scheduled";
            paused: "paused";
        }>;
        nextRunAt: z.ZodNullable<z.ZodISODateTime>;
        lastRun: z.ZodOptional<z.ZodObject<{
            id: z.ZodString;
            taskId: z.ZodString;
            employeeId: z.ZodString;
            taskName: z.ZodString;
            status: z.ZodEnum<{
                queued: "queued";
                claimed: "claimed";
                running: "running";
                succeeded: "succeeded";
                failed: "failed";
                cancelled: "cancelled";
                "timed-out": "timed-out";
                expired: "expired";
            }>;
            trigger: z.ZodEnum<{
                schedule: "schedule";
                manual: "manual";
            }>;
            scheduledAt: z.ZodISODateTime;
            queuedAt: z.ZodISODateTime;
            claimedAt: z.ZodOptional<z.ZodISODateTime>;
            startedAt: z.ZodOptional<z.ZodISODateTime>;
            finishedAt: z.ZodOptional<z.ZodISODateTime>;
            summary: z.ZodDefault<z.ZodString>;
            errorCode: z.ZodDefault<z.ZodString>;
            sessionId: z.ZodOptional<z.ZodString>;
            autoDecisions: z.ZodOptional<z.ZodNumber>;
            artifact: z.ZodOptional<z.ZodObject<{
                size: z.ZodNumber;
                sha256: z.ZodString;
                fileCount: z.ZodNumber;
            }, z.core.$strict>>;
            cancelRequested: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strict>>;
        revision: z.ZodNumber;
        createdAt: z.ZodISODateTime;
        updatedAt: z.ZodISODateTime;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const RunListQuerySchema: z.ZodObject<{
    taskId: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    offset: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
}, z.core.$strict>;
export declare const RunListResponseSchema: z.ZodObject<{
    runs: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        taskId: z.ZodString;
        employeeId: z.ZodString;
        taskName: z.ZodString;
        status: z.ZodEnum<{
            queued: "queued";
            claimed: "claimed";
            running: "running";
            succeeded: "succeeded";
            failed: "failed";
            cancelled: "cancelled";
            "timed-out": "timed-out";
            expired: "expired";
        }>;
        trigger: z.ZodEnum<{
            schedule: "schedule";
            manual: "manual";
        }>;
        scheduledAt: z.ZodISODateTime;
        queuedAt: z.ZodISODateTime;
        claimedAt: z.ZodOptional<z.ZodISODateTime>;
        startedAt: z.ZodOptional<z.ZodISODateTime>;
        finishedAt: z.ZodOptional<z.ZodISODateTime>;
        summary: z.ZodDefault<z.ZodString>;
        errorCode: z.ZodDefault<z.ZodString>;
        sessionId: z.ZodOptional<z.ZodString>;
        autoDecisions: z.ZodOptional<z.ZodNumber>;
        artifact: z.ZodOptional<z.ZodObject<{
            size: z.ZodNumber;
            sha256: z.ZodString;
            fileCount: z.ZodNumber;
        }, z.core.$strict>>;
        cancelRequested: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>>;
    total: z.ZodNumber;
}, z.core.$strict>;
export declare const RunResponseSchema: z.ZodObject<{
    run: z.ZodObject<{
        id: z.ZodString;
        taskId: z.ZodString;
        employeeId: z.ZodString;
        taskName: z.ZodString;
        status: z.ZodEnum<{
            queued: "queued";
            claimed: "claimed";
            running: "running";
            succeeded: "succeeded";
            failed: "failed";
            cancelled: "cancelled";
            "timed-out": "timed-out";
            expired: "expired";
        }>;
        trigger: z.ZodEnum<{
            schedule: "schedule";
            manual: "manual";
        }>;
        scheduledAt: z.ZodISODateTime;
        queuedAt: z.ZodISODateTime;
        claimedAt: z.ZodOptional<z.ZodISODateTime>;
        startedAt: z.ZodOptional<z.ZodISODateTime>;
        finishedAt: z.ZodOptional<z.ZodISODateTime>;
        summary: z.ZodDefault<z.ZodString>;
        errorCode: z.ZodDefault<z.ZodString>;
        sessionId: z.ZodOptional<z.ZodString>;
        autoDecisions: z.ZodOptional<z.ZodNumber>;
        artifact: z.ZodOptional<z.ZodObject<{
            size: z.ZodNumber;
            sha256: z.ZodString;
            fileCount: z.ZodNumber;
        }, z.core.$strict>>;
        cancelRequested: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const UpdateTaskRequestSchema: z.ZodObject<{
    expectedRevision: z.ZodNumber;
    definition: z.ZodObject<{
        name: z.ZodString;
        description: z.ZodDefault<z.ZodString>;
        expertId: z.ZodString;
        skillNames: z.ZodDefault<z.ZodArray<z.ZodString>>;
        prompt: z.ZodString;
        schedule: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"once">;
            at: z.ZodISODateTime;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"interval">;
            everyMinutes: z.ZodNumber;
            anchorAt: z.ZodISODateTime;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"calendar">;
            frequency: z.ZodEnum<{
                daily: "daily";
                weekly: "weekly";
                monthly: "monthly";
            }>;
            time: z.ZodString;
            timeZone: z.ZodString;
            weekdays: z.ZodOptional<z.ZodArray<z.ZodNumber>>;
            dayOfMonth: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>], "kind">;
        activeFrom: z.ZodOptional<z.ZodISODateTime>;
        activeUntil: z.ZodOptional<z.ZodISODateTime>;
        timeoutMinutes: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const TaskStateRequestSchema: z.ZodObject<{
    expectedRevision: z.ZodNumber;
    state: z.ZodEnum<{
        scheduled: "scheduled";
        paused: "paused";
    }>;
}, z.core.$strict>;
export declare const ExecutorHeartbeatSchema: z.ZodObject<{
    contractVersion: z.ZodLiteral<1>;
    instanceId: z.ZodString;
    bundleVersion: z.ZodString;
    dshVersion: z.ZodString;
    catalog: z.ZodObject<{
        generatedAt: z.ZodISODateTime;
        defaultExpertId: z.ZodString;
        experts: z.ZodArray<z.ZodObject<{
            id: z.ZodString;
            presetId: z.ZodString;
            name: z.ZodString;
            summary: z.ZodDefault<z.ZodString>;
            available: z.ZodBoolean;
            skills: z.ZodArray<z.ZodObject<{
                name: z.ZodString;
                description: z.ZodDefault<z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    runningRunIds: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export type ExecutorHeartbeat = z.infer<typeof ExecutorHeartbeatSchema>;
export declare const HeartbeatResponseSchema: z.ZodObject<{
    cancelRunIds: z.ZodArray<z.ZodString>;
    pollIntervalMs: z.ZodNumber;
    drain: z.ZodBoolean;
}, z.core.$strict>;
export type HeartbeatResponse = z.infer<typeof HeartbeatResponseSchema>;
export declare const ClaimRequestSchema: z.ZodObject<{
    instanceId: z.ZodString;
}, z.core.$strict>;
export declare const ClaimedRunSchema: z.ZodObject<{
    run: z.ZodObject<{
        id: z.ZodString;
        taskId: z.ZodString;
        employeeId: z.ZodString;
        taskName: z.ZodString;
        status: z.ZodEnum<{
            queued: "queued";
            claimed: "claimed";
            running: "running";
            succeeded: "succeeded";
            failed: "failed";
            cancelled: "cancelled";
            "timed-out": "timed-out";
            expired: "expired";
        }>;
        trigger: z.ZodEnum<{
            schedule: "schedule";
            manual: "manual";
        }>;
        scheduledAt: z.ZodISODateTime;
        queuedAt: z.ZodISODateTime;
        claimedAt: z.ZodOptional<z.ZodISODateTime>;
        startedAt: z.ZodOptional<z.ZodISODateTime>;
        finishedAt: z.ZodOptional<z.ZodISODateTime>;
        summary: z.ZodDefault<z.ZodString>;
        errorCode: z.ZodDefault<z.ZodString>;
        sessionId: z.ZodOptional<z.ZodString>;
        autoDecisions: z.ZodOptional<z.ZodNumber>;
        artifact: z.ZodOptional<z.ZodObject<{
            size: z.ZodNumber;
            sha256: z.ZodString;
            fileCount: z.ZodNumber;
        }, z.core.$strict>>;
        cancelRequested: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>;
    definition: z.ZodObject<{
        name: z.ZodString;
        description: z.ZodDefault<z.ZodString>;
        expertId: z.ZodString;
        skillNames: z.ZodDefault<z.ZodArray<z.ZodString>>;
        prompt: z.ZodString;
        schedule: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"once">;
            at: z.ZodISODateTime;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"interval">;
            everyMinutes: z.ZodNumber;
            anchorAt: z.ZodISODateTime;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"calendar">;
            frequency: z.ZodEnum<{
                daily: "daily";
                weekly: "weekly";
                monthly: "monthly";
            }>;
            time: z.ZodString;
            timeZone: z.ZodString;
            weekdays: z.ZodOptional<z.ZodArray<z.ZodNumber>>;
            dayOfMonth: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>], "kind">;
        activeFrom: z.ZodOptional<z.ZodISODateTime>;
        activeUntil: z.ZodOptional<z.ZodISODateTime>;
        timeoutMinutes: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>;
    leaseMs: z.ZodNumber;
}, z.core.$strict>;
export type ClaimedRun = z.infer<typeof ClaimedRunSchema>;
export declare const RunProgressSchema: z.ZodObject<{
    status: z.ZodLiteral<"running">;
    startedAt: z.ZodISODateTime;
    sessionId: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type RunProgress = z.infer<typeof RunProgressSchema>;
export declare const RunCompletionSchema: z.ZodObject<{
    status: z.ZodEnum<{
        succeeded: "succeeded";
        failed: "failed";
        cancelled: "cancelled";
        "timed-out": "timed-out";
    }>;
    finishedAt: z.ZodISODateTime;
    summary: z.ZodDefault<z.ZodString>;
    errorCode: z.ZodDefault<z.ZodString>;
    sessionId: z.ZodOptional<z.ZodString>;
    autoDecisions: z.ZodOptional<z.ZodNumber>;
    artifact: z.ZodOptional<z.ZodObject<{
        size: z.ZodNumber;
        sha256: z.ZodString;
        fileCount: z.ZodNumber;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type RunCompletion = z.infer<typeof RunCompletionSchema>;
export declare const errorCodes: readonly ["UNAUTHORIZED", "FORBIDDEN", "NOT_FOUND", "INVALID_REQUEST", "REVISION_CONFLICT", "TASK_RUNNING", "QUEUE_FULL", "INSTANCE_UNAVAILABLE", "ARTIFACT_TOO_LARGE", "ARTIFACT_MISMATCH", "RATE_LIMITED", "METHOD_NOT_ALLOWED", "CLOUD_NOT_ENABLED", "CONTRACT_VERSION_MISMATCH", "INTERNAL"];
export declare const ErrorResponseSchema: z.ZodObject<{
    error: z.ZodEnum<{
        UNAUTHORIZED: "UNAUTHORIZED";
        FORBIDDEN: "FORBIDDEN";
        NOT_FOUND: "NOT_FOUND";
        INVALID_REQUEST: "INVALID_REQUEST";
        REVISION_CONFLICT: "REVISION_CONFLICT";
        TASK_RUNNING: "TASK_RUNNING";
        QUEUE_FULL: "QUEUE_FULL";
        INSTANCE_UNAVAILABLE: "INSTANCE_UNAVAILABLE";
        ARTIFACT_TOO_LARGE: "ARTIFACT_TOO_LARGE";
        ARTIFACT_MISMATCH: "ARTIFACT_MISMATCH";
        RATE_LIMITED: "RATE_LIMITED";
        METHOD_NOT_ALLOWED: "METHOD_NOT_ALLOWED";
        CLOUD_NOT_ENABLED: "CLOUD_NOT_ENABLED";
        CONTRACT_VERSION_MISMATCH: "CONTRACT_VERSION_MISMATCH";
        INTERNAL: "INTERNAL";
    }>;
    message: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type CloudErrorCode = (typeof errorCodes)[number];
export declare const CLOUD_API_BASE: "/api/cloud/v1";
export declare const cloudRoutes: Readonly<{
    me: "/api/cloud/v1/me";
    catalog: "/api/cloud/v1/catalog";
    tasks: "/api/cloud/v1/tasks";
    task: (taskId: string) => string;
    taskState: (taskId: string) => string;
    taskRun: (taskId: string) => string;
    runs: "/api/cloud/v1/runs";
    run: (runId: string) => string;
    runCancel: (runId: string) => string;
    runArtifact: (runId: string) => string;
    executorHeartbeat: "/api/cloud/v1/executor/heartbeat";
    executorClaim: "/api/cloud/v1/executor/claim";
    executorProgress: (runId: string) => string;
    executorArtifact: (runId: string) => string;
    executorComplete: (runId: string) => string;
}>;
/** Parse a `Bearer <token>` header; undefined when absent or malformed. */
export declare function bearerToken(header: string | undefined): string | undefined;
//# sourceMappingURL=index.d.ts.map
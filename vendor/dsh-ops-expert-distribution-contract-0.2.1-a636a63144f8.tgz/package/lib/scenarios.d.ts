/**
 * Expert scenarios: the product's "常用场景" of one expert. A scenario is a titled prompt template the
 * user picks on the blank-session home page or an expert card; picking one only prefills the composer
 * (it never sends). This module has no dependencies so the browser clients can bundle it
 * (`@dsh-ops/expert-distribution-contract/scenarios`).
 *
 * Reads are lenient (`normalizeScenarios`): a malformed item is dropped, never the expert. Writes are
 * strict (`scenarioIssues`): the editor, the export and the website's publish step reject what a
 * reader would drop, so nothing an author saved silently disappears on the way.
 */
export declare const SCENARIO_LIMITS: Readonly<{
    /** Scenarios per expert. */
    perExpert: 8;
    idLength: 40;
    titleLength: 16;
    summaryLength: 40;
    promptLength: 300;
    /** `【…】` slots the user fills in before sending. */
    placeholders: 3;
}>;
/**
 * Conversation modes a scenario can open in. Absent means 日常办公; a mode this client does not know
 * (a newer website) reads as absent, so the prompt still lands in 日常办公.
 */
export declare const SCENARIO_MODE_IDS: readonly ["ppt", "design", "skill-studio"];
export type ScenarioModeId = typeof SCENARIO_MODE_IDS[number];
export declare const SCENARIO_MODE_LABELS: Readonly<Record<ScenarioModeId, string>>;
/**
 * Icons a scenario may carry (optional). Every renderer draws them from `SCENARIO_ICON_SHAPES`, so the
 * home panel, the expert market and the website editor show the same glyph.
 */
export declare const SCENARIO_ICONS: readonly ["chart", "activity", "database", "document", "presentation", "megaphone", "gift", "target", "calendar", "repeat", "layers", "shield", "help", "search", "pen", "star"];
export type ScenarioIcon = typeof SCENARIO_ICONS[number];
export declare const SCENARIO_ICON_LABELS: Readonly<Record<ScenarioIcon, string>>;
/** One SVG child element of a 24×24, stroke-drawn icon (stroke-width 1.8, round caps and joins). */
export type ScenarioIconShape = readonly ['path', {
    readonly d: string;
}] | readonly ['circle', {
    readonly cx: number;
    readonly cy: number;
    readonly r: number;
}] | readonly ['rect', {
    readonly x: number;
    readonly y: number;
    readonly width: number;
    readonly height: number;
    readonly rx: number;
}] | readonly ['ellipse', {
    readonly cx: number;
    readonly cy: number;
    readonly rx: number;
    readonly ry: number;
}];
/** Glyphs of `SCENARIO_ICONS` (Lucide-derived shapes, ISC license). Renderers create the elements. */
export declare const SCENARIO_ICON_SHAPES: Readonly<Record<ScenarioIcon, readonly ScenarioIconShape[]>>;
/** The glyph a scenario without its own icon shows for its mode. */
export declare const SCENARIO_MODE_ICONS: Readonly<Record<ScenarioModeId, ScenarioIcon>>;
export declare function isScenarioIcon(value: unknown): value is ScenarioIcon;
/**
 * The icon to draw for a scenario: its own icon, else its mode's, else one borrowed from the expert's
 * appearance icon, else `document`.
 */
export declare function scenarioIconFor(scenario: {
    icon?: unknown;
    modeId?: unknown;
}, expertIcon?: unknown): ScenarioIcon;
export declare const SCENARIO_ID_PATTERN: RegExp;
export interface ExpertScenario {
    id: string;
    title: string;
    summary?: string;
    prompt: string;
    modeId?: ScenarioModeId;
    /** Optional glyph; absent means the mode's or the expert's (see `scenarioIconFor`). */
    icon?: ScenarioIcon;
}
export interface ScenarioIssue {
    /** Index of the scenario in the list; absent for a list-level issue (too many). */
    index?: number;
    field?: 'id' | 'title' | 'summary' | 'prompt' | 'modeId' | 'icon';
    message: string;
}
export declare function isScenarioModeId(value: unknown): value is ScenarioModeId;
/** Length in characters (code points), the unit the editors count. */
export declare function scenarioTextLength(value: string): number;
/** Number of `【…】` slots in a prompt template. */
export declare function countScenarioPlaceholders(prompt: string): number;
/**
 * Every reason a scenario list cannot be saved or published: shape, lengths, `【】` count, unique ids
 * and names, known modes, no secrets. An empty result means the list is publishable as is.
 */
export declare function scenarioIssues(value: unknown): ScenarioIssue[];
/**
 * The canonical form of a valid scenario (trimmed, CRLF folded, optional keys dropped when empty).
 * Call only on items `scenarioIssues` accepted; both sides store and compare this form.
 */
export declare function canonicalScenario(value: ExpertScenario): ExpertScenario;
/**
 * Lenient read: keep every valid scenario in order (canonical form), drop malformed ones, unknown
 * keys and duplicates (first wins), read an unknown mode as 日常办公, stop at the per-expert limit.
 * Never throws; anything that is not a list reads as no scenarios.
 */
export declare function normalizeScenarios(value: unknown): ExpertScenario[];
/**
 * What a client without scenario support shows as prompt suggestions: the scenario names (the
 * templates carry `【】` slots that read badly as ready-to-send prompts).
 */
export declare function deriveStarterPrompts(scenarios: readonly ExpertScenario[]): string[];
/** A fresh scenario id not in `taken` (`s-` + 6 base-36 characters from `random`, default Math.random). */
export declare function newScenarioId(taken?: Iterable<string>, random?: () => number): string;
//# sourceMappingURL=scenarios.d.ts.map
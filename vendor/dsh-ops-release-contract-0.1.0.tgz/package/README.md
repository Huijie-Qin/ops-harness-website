# @dsh-ops/release-contract

Desktop 与官网共同使用的版本、平台、URL、发布目录和更新决策 schema。纯数据包，不注册 Cordis 插件，不访问网络或文件系统。公开契约版本为 schemaVersion: 1。

Desktop 和 src/website 都显式依赖本包，构建会生成 lib。变更须同步两端与契约测试；架构见 [升级 ADR](../../../docs/adr/0011-desktop-updates-and-product-website.md)。

运行时依赖均来自 npm，使用精确版本：semver 7.8.5（npm/node-semver，ISC）与 zod 4.4.3（colinhacks/zod，MIT），无原生构建需求。升级前复查版本排序、预览版筛选、严格 schema 与错误处理，不能放宽旧客户端的 URL 或文件边界。

# @dsh-ops/expert-distribution-contract

云端专家分发的共享契约：专家包格式、官网公开目录结构、校验规则与上限。产品仓库（导出专家包、读取云端目录）和官网
（导入专家包、按工号提供目录）使用同一份校验，官网以精确版本的 pnpm pack 制品离线消费（见官网 `vendor/README.md`）。

纯契约包：只依赖 `zod`，不导入 DSH、Cordis 或 Node 专有模块。

## 内容

| 导出 | 说明 |
| --- | --- |
| `ExpertPackageManifestSchema` / `ExpertPackageDefinitionSchema` | 专家包的 `manifest.json` 与 `expert.json` |
| `CustomToolDefinitionSchema` / `customToolPortabilityIssues` | 自定义 MCP 工具的可分发配置；密钥只能以凭据项（`{{credential:<key>}}`）出现，依赖本机路径的命令被拒绝 |
| `CloudExpertSchema` / `parseCloudExpertCatalog` | 官网公开目录；单条坏数据被过滤并报告，不拖垮整份目录 |
| `isExpertVisible` / `normalizeEmployeeId` | 可见范围判定（全员 / 白名单 / 负责人）与工号归一 |
| `BUILTIN_TOOLS` / `EXPERT_CATEGORIES` / `EXPERT_ICONS` / `BUILTIN_CAPABILITIES` | 产品的内置工具、分类、图标与五项基础能力；测试保证与 `experts/` 源目录一致 |
| `EXPERT_ROUTES` / `EMPLOYEE_ID_HEADER` | 公开接口路径与工号请求头 |
| `scenarioIssues` / `normalizeScenarios` / `ScenariosSchema`（子路径 `./scenarios` 无依赖，浏览器可打包） | 专家常用场景：发布端严格校验（字数、【】个数、ID 与名称唯一、工作模式、图标、不含密钥），读取端宽松（坏条目丢弃、未知模式按日常办公、未知图标去掉） |
| `SCENARIO_ICONS` / `SCENARIO_ICON_LABELS` / `SCENARIO_ICON_SHAPES` / `scenarioIconFor`（同在 `./scenarios`） | 场景的可选图标：16 个名称、中文名与图形数据（产品与官网按同一份数据绘制）；显示取场景自带 → 工作模式 → 专家外观图标 → 文档图标 |
| `BUILTIN_EXPERTS` / `BuiltinScenarioOverrideSchema` | 随产品发布的五位专家；官网可整表替换它们的常用场景（`[]` 表示不显示，没有覆盖即随产品发布） |
| `EXPERT_FEATURES_HEADER` / `parseExpertFeatures` | 客户端声明读取的可选字段；官网只对声明了 `scenarios` 的客户端下发 `experts[].scenarios` 与 `builtinScenarios` |

读取端（`CloudExpertSchema`、目录外层）忽略未知字段，官网新增字段不会让旧客户端丢专家或整份目录失败；
发布端（`ExpertPackageDefinitionSchema`、官网草稿与覆盖）仍然严格。因此导出方向有部署顺序：官网先升级到 0.1.1，
再发布会导出 `scenarios` 的产品版本（0.1.0 的官网会拒收带该字段的专家包）。

专家包结构：

```text
专家名-日期.expert.zip
├── manifest.json      # 格式、版本、来源（本机专家 ID、导出人工号）、各文件大小与 SHA-256
├── expert.json        # 展示信息、基础能力、技能清单、工具（内置引用 / 自定义工具定义）、知识库引用、负责人
├── AGENTS.md          # 职责
└── skills/<name>.zip  # 每个技能一个 ZIP（根下或唯一一级目录下一个 SKILL.md）
```

包里没有任何密钥、知识库正文或本机路径。设计见 `docs/specs/2026-09-26-cloud-expert-distribution-design.md`。

## 开发

```bash
pnpm --filter @dsh-ops/expert-distribution-contract build
pnpm --filter @dsh-ops/expert-distribution-contract test
pnpm --dir packages/shared/expert-distribution-contract pack --pack-destination <官网仓库>/vendor
```

改动契约时递增精确版本，重新打包并更新官网的制品路径、来源清单与锁文件。

/**
 * One Skill's files: the rules every side of expert distribution applies to a Skill, so a Skill the
 * product's 我的技能 accepts (ADR 0032) also exports, passes the website's package import and installs
 * on a colleague's machine. The product's import normalizer enforces the same numbers.
 *
 * Each side reads archives its own way (the website has its own ZIP reader, the product uses fflate);
 * what it then checks is the list of files it read — paths relative to the Skill folder and their
 * sizes — and the `name` / `description` of `SKILL.md`. This module has no dependencies
 * (`@dsh-ops/expert-distribution-contract/skill-tree`).
 */
export declare const SKILL_TREE_LIMITS: Readonly<{
    /** Files of one Skill, not counting folders or what is never content (`isIgnoredSkillPath`). */
    files: 2000;
    /** Bytes of all those files once extracted. */
    extractedBytes: number;
    /** Levels of a path inside the Skill folder, the file itself included. */
    depth: 32;
    /** UTF-16 units of one file or folder name. */
    segmentLength: 120;
    /** UTF-16 units of a path inside the Skill folder. */
    pathLength: 180;
    /** `name` of `SKILL.md`. */
    nameLength: 64;
    /** `SKILL.md` itself. */
    manifestBytes: number;
    /** Entries a Skill archive may list: files, folders and OS metadata together. */
    archiveEntries: 4096;
}>;
/**
 * What clients released before these rules (contract 0.1.x) install. They refuse a Skill or an expert
 * beyond it until they are updated, so the website warns before it publishes one.
 */
export declare const LEGACY_CLIENT_LIMITS: Readonly<{
    /** Skills of one expert. */
    skills: 20;
    /** One Skill archive as downloaded. */
    skillArchiveBytes: number;
    /** Entries of one Skill archive, folders and OS metadata included. */
    skillArchiveEntries: 256;
    /** All files of one Skill once extracted. */
    extractedBytes: number;
    /** Levels of an archive entry name, the Skill folder included. */
    archiveDepth: 16;
    /** `description` of `SKILL.md`. */
    descriptionLength: 500;
}>;
/** One file of a Skill: path relative to the Skill folder (`/`-separated) and its extracted size. */
export interface SkillTreeEntry {
    path: string;
    size: number;
}
export type SkillTreeIssueCode = 'missing-manifest' | 'too-many-files' | 'too-large' | 'manifest-too-large' | 'invalid-path' | 'segment-too-long' | 'path-too-long' | 'path-too-deep' | 'duplicate-path' | 'invalid-name' | 'missing-description' | 'name-mismatch';
export interface SkillTreeIssue {
    code: SkillTreeIssueCode;
    /** One sentence for the person fixing the Skill. */
    message: string;
    path?: string;
}
/**
 * What is never Skill content: anything under a folder of {@link IGNORED_DIRECTORIES} (`.git`,
 * `node_modules`, `.venv`, `__pycache__`, `__MACOSX`, …), dependency lock files
 * (`package-lock.json`, `yarn.lock`, `pnpm-lock.yaml`, `uv.lock`, …), OS metadata (`.DS_Store`,
 * `Thumbs.db`, `desktop.ini`, AppleDouble `._*`), Office lock files (`~$*`) and Python bytecode.
 * Readers drop these and do not count them; an export leaves them out.
 */
export declare function isIgnoredSkillPath(path: string): boolean;
/** Why one path inside a Skill folder cannot be used, or `undefined` when it can. */
export declare function skillPathIssue(path: string): SkillTreeIssue | undefined;
/**
 * Issues of one Skill's files (folders and `isIgnoredSkillPath` files already left out). `SKILL.md`
 * must sit at the Skill folder's root; a `SKILL.md` deeper inside (a template, an example) is an
 * ordinary file.
 */
export declare function skillTreeIssues(entries: readonly SkillTreeEntry[]): SkillTreeIssue[];
/**
 * Issues of `SKILL.md`'s `name` and `description` (already parsed from its frontmatter). `expectedName`
 * is the name the Skill travels under (its folder in the archive, its entry in the expert).
 * The description has no length limit beyond `SKILL.md`'s size, as in 我的技能.
 */
export declare function skillManifestIssues(fields: {
    name: unknown;
    description: unknown;
}, expectedName?: string): SkillTreeIssue[];
/** What an archive reader learned about one Skill archive, for {@link legacyClientIssues}. */
export interface SkillArchiveFacts {
    /** Bytes of the archive. */
    archiveBytes: number;
    /** Entries its central directory lists (folders and OS metadata included). */
    archiveEntries: number;
    /** Bytes of all entries once extracted. */
    extractedBytes: number;
    /** Most `/`-separated levels of an entry name, the Skill folder included. */
    archiveDepth: number;
    /** Entries named `SKILL.md` at any depth. */
    manifests: number;
    /** Length of `SKILL.md`'s description. */
    descriptionLength: number;
}
/** Why a client released before these rules would refuse this Skill (empty when it would install it). */
export declare function legacyClientIssues(facts: SkillArchiveFacts): string[];
//# sourceMappingURL=skill-tree.d.ts.map
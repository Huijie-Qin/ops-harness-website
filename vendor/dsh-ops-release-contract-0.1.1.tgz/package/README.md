# @dsh-ops/release-contract

Desktop 与官网共同使用的版本、平台、URL、发布目录和更新决策 schema。纯数据包，不注册 Cordis 插件，不访问网络或文件系统。公开契约版本为 schemaVersion: 1。

Desktop 显式依赖本 workspace 包；独立官网 ops-harness-website 使用本包的精确版本 pnpm pack 制品，构建会生成 lib。变更须同步两端与契约测试；架构见 [升级 ADR](../../../docs/adr/0011-desktop-updates-and-product-website.md)。

0.1.1 按用户要求统一支持显式 HTTP 或 HTTPS 官网源地址，包括 IP、域名和 IPv6。仍拒绝凭据、子路径、查询串、fragment 及其他协议；更新决策继续固定协议、主机、端口、版本、平台和归档路径，不自动降级 HTTPS。旧客户端仍执行各自内置的校验规则。

运行时依赖均来自 npm，使用精确版本：semver 7.8.5（npm/node-semver，ISC）与 zod 4.4.3（colinhacks/zod，MIT），无原生构建需求。升级前复查版本排序、预览版筛选、严格 schema 与错误处理；URL 边界变化须记录产品决策并验证两端。

官网迁移与制品更新流程见 [ADR 0014](../../../docs/adr/0014-standalone-website-repository.md)。协议源码只在这里维护；变更后递增版本、运行契约及 Desktop 更新测试，构建并打包，再更新官网 vendor 制品、来源清单和锁文件。不得覆盖同版本制品。

import { z } from 'zod';
export declare const PROTOCOL_VERSION: 1;
export declare const platforms: readonly ["windows-x64", "macos-arm64"];
export declare const PlatformSchema: z.ZodEnum<{
    "windows-x64": "windows-x64";
    "macos-arm64": "macos-arm64";
}>;
export type ReleasePlatform = z.infer<typeof PlatformSchema>;
export declare const VersionSchema: z.ZodString;
export declare const InstallationIdSchema: z.ZodString;
export declare const FileNameSchema: z.ZodString;
export declare const ArtifactSchema: z.ZodObject<{
    name: z.ZodString;
    size: z.ZodNumber;
    sha512: z.ZodString;
}, z.core.$strict>;
export type ReleaseArtifact = z.infer<typeof ArtifactSchema>;
export declare function normalizeWebsiteUrl(value: string): string;
export declare const ReleaseConfigSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    websiteUrl: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    host: z.ZodDefault<z.ZodString>;
    port: z.ZodDefault<z.ZodNumber>;
    releaseDirectory: z.ZodString;
}, z.core.$strict>;
export declare const ReleaseNotesSchema: z.ZodObject<{
    title: z.ZodString;
    notes: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export declare const ReleaseSchema: z.ZodObject<{
    title: z.ZodString;
    notes: z.ZodArray<z.ZodString>;
    version: z.ZodString;
    publishedAt: z.ZodString;
    enabled: z.ZodBoolean;
    rolloutPercentage: z.ZodNumber;
    minimumVersion: z.ZodOptional<z.ZodString>;
    targets: z.ZodObject<{
        'windows-x64': z.ZodOptional<z.ZodObject<{
            artifact: z.ZodObject<{
                name: z.ZodString;
                size: z.ZodNumber;
                sha512: z.ZodString;
            }, z.core.$strict>;
            downloads: z.ZodArray<z.ZodObject<{
                name: z.ZodString;
                size: z.ZodNumber;
                sha512: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        'macos-arm64': z.ZodOptional<z.ZodObject<{
            artifact: z.ZodObject<{
                name: z.ZodString;
                size: z.ZodNumber;
                sha512: z.ZodString;
            }, z.core.$strict>;
            downloads: z.ZodArray<z.ZodObject<{
                name: z.ZodString;
                size: z.ZodNumber;
                sha512: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export type Release = z.infer<typeof ReleaseSchema>;
export declare const CatalogSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    releases: z.ZodArray<z.ZodObject<{
        title: z.ZodString;
        notes: z.ZodArray<z.ZodString>;
        version: z.ZodString;
        publishedAt: z.ZodString;
        enabled: z.ZodBoolean;
        rolloutPercentage: z.ZodNumber;
        minimumVersion: z.ZodOptional<z.ZodString>;
        targets: z.ZodObject<{
            'windows-x64': z.ZodOptional<z.ZodObject<{
                artifact: z.ZodObject<{
                    name: z.ZodString;
                    size: z.ZodNumber;
                    sha512: z.ZodString;
                }, z.core.$strict>;
                downloads: z.ZodArray<z.ZodObject<{
                    name: z.ZodString;
                    size: z.ZodNumber;
                    sha512: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            'macos-arm64': z.ZodOptional<z.ZodObject<{
                artifact: z.ZodObject<{
                    name: z.ZodString;
                    size: z.ZodNumber;
                    sha512: z.ZodString;
                }, z.core.$strict>;
                downloads: z.ZodArray<z.ZodObject<{
                    name: z.ZodString;
                    size: z.ZodNumber;
                    sha512: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ReleaseCatalog = z.infer<typeof CatalogSchema>;
export declare const CheckQuerySchema: z.ZodObject<{
    installationId: z.ZodString;
    currentVersion: z.ZodString;
    platform: z.ZodEnum<{
        "windows-x64": "windows-x64";
        "macos-arm64": "macos-arm64";
    }>;
}, z.core.$strict>;
export declare const UpdateDecisionSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    updateAvailable: z.ZodLiteral<false>;
}, z.core.$strict>, z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    updateAvailable: z.ZodLiteral<true>;
    version: z.ZodString;
    platform: z.ZodEnum<{
        "windows-x64": "windows-x64";
        "macos-arm64": "macos-arm64";
    }>;
    feedUrl: z.ZodString;
    releaseNotesUrl: z.ZodString;
    artifact: z.ZodObject<{
        name: z.ZodString;
        size: z.ZodNumber;
        sha512: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>], "updateAvailable">;
export type UpdateDecision = z.infer<typeof UpdateDecisionSchema>;
export declare function compareVersions(a: string, b: string): number;
export declare function isPrerelease(version: string): boolean;
export declare function archiveUrl(websiteUrl: string, version: string, platform: ReleasePlatform): string;
export declare function releaseNotesUrl(websiteUrl: string, version: string): string;
export declare function validateUpdateDecision(raw: unknown, websiteUrl: string, currentVersion: string, platform: ReleasePlatform): UpdateDecision;
//# sourceMappingURL=index.d.ts.map
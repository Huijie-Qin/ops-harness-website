import { type TrackingEvent, type BatchResponse } from './contracts.js';
export type PendingRecord = {
    file: string;
    end: number;
    event: TrackingEvent;
};
export type SpoolOptions = {
    fileBytes?: number;
    quotaBytes?: number;
    memoryBytes?: number;
    retentionMs?: number;
};
export declare class EventSpool {
    readonly root: string;
    readonly installationId: string;
    private handle;
    private file;
    private fileBytes;
    private totalBytes;
    private queueBytes;
    private accepting;
    private writeFaulted;
    private listeners;
    private tail;
    private offsets;
    private durable;
    private limits;
    private releaseLock;
    readonly health: {
        queued: number;
        written: number;
        dropped: number;
        rejected: number;
        error: string;
        pendingBytes: number;
    };
    private constructor();
    static create(root: string, options?: SpoolOptions): Promise<EventSpool>;
    private initialize;
    private files;
    private measure;
    enqueue(event: TrackingEvent): boolean;
    private rotate;
    subscribe(listener: () => void): () => void;
    flush(): Promise<void>;
    pending(limit?: number): Promise<PendingRecord[]>;
    acknowledge(records: PendingRecord[], response: BatchResponse): Promise<void>;
    private commitAcknowledgement;
    private cleanup;
    close(): Promise<void>;
}
export declare function atomicJson(filename: string, value: unknown): Promise<void>;
//# sourceMappingURL=event-file.d.ts.map
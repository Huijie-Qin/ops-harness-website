# @dsh-ops/expert-distribution-contract

云端专家分发的共享契约：专家包格式、官网公开目录结构、校验规则与上限。产品仓库（导出专家包、读取云端目录）和官网
（导入专家包、按工号提供目录）使用同一份校验，官网以精确版本的 pnpm pack 制品离线消费（见官网 `vendor/README.md`）。

纯契约包：只依赖 `zod`，不导入 DSH、Cordis 或 Node 专有模块。

## 内容

| 导出 | 说明 |
| --- | --- |
| `ExpertPackageManifestSchema` / `ExpertPackageDefinitionSchema` | 专家包的 `manifest.json` 与 `expert.json` |
| `CustomToolDefinitionSchema` / `customToolPortabilityIssues` | 自定义 MCP 工具的可分发配置；密钥只能以凭据项（`{{credential:<key>}}`）出现，依赖本机路径的命令被拒绝 |
| `CloudExpertSchema` / `parseCloudExpertCatalog` | 官网公开目录；单条坏数据被过滤并报告，不拖垮整份目录 |
| `isExpertVisible` / `normalizeEmployeeId` | 可见范围判定（全员 / 白名单 / 负责人）与工号归一 |
| `BUILTIN_TOOLS` / `EXPERT_CATEGORIES` / `EXPERT_ICONS` / `BUILTIN_CAPABILITIES` | 产品的内置工具、分类、图标与五项基础能力；测试保证与 `experts/` 源目录一致 |
| `EXPERT_ROUTES` / `EMPLOYEE_ID_HEADER` | 公开接口路径与工号请求头 |

专家包结构：

```text
专家名-日期.expert.zip
├── manifest.json      # 格式、版本、来源（本机专家 ID、导出人工号）、各文件大小与 SHA-256
├── expert.json        # 展示信息、基础能力、技能清单、工具（内置引用 / 自定义工具定义）、知识库引用、负责人
├── AGENTS.md          # 职责
└── skills/<name>.zip  # 每个技能一个 ZIP（根下或唯一一级目录下一个 SKILL.md）
```

包里没有任何密钥、知识库正文或本机路径。设计见 `docs/specs/2026-09-26-cloud-expert-distribution-design.md`。

## 开发

```bash
pnpm --filter @dsh-ops/expert-distribution-contract build
pnpm --filter @dsh-ops/expert-distribution-contract test
pnpm --dir packages/shared/expert-distribution-contract pack --pack-destination <官网仓库>/vendor
```

改动契约时递增精确版本，重新打包并更新官网的制品路径、来源清单与锁文件。

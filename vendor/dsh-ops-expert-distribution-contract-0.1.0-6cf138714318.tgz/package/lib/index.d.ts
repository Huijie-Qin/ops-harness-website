import { z } from 'zod';
/**
 * Cloud expert distribution contract. The product exports expert packages and reads the public
 * catalog with these schemas; the website vendors this package (exact-version tarball) to import
 * packages and serve the catalog. Both sides validate with the same rules, so a package the product
 * lets through never fails on the website for a reason the exporter was not shown.
 */
export declare const CONTRACT_VERSION: 1;
export declare const PACKAGE_FORMAT: "dsh-ops-expert-package";
export declare const PACKAGE_SCHEMA_VERSION: 1;
export declare const CATALOG_SCHEMA_VERSION: 1;
/** Request header carrying the WeLink employee id the catalog is filtered for (lower-case). */
export declare const EMPLOYEE_ID_HEADER = "x-ops-employee-id";
/** Local Agent Preset id of a cloud expert: never collides with shipped or custom expert ids. */
export declare const CLOUD_PRESET_PREFIX = "cloud-";
/** Local custom tool id of a cloud custom tool (fits the custom tool id grammar). */
export declare const CLOUD_CUSTOM_TOOL_PREFIX = "custom-cloud-";
export declare const PACKAGE_FILE_SUFFIX = ".expert.zip";
export declare const PACKAGE_MANIFEST_FILE = "manifest.json";
export declare const PACKAGE_DEFINITION_FILE = "expert.json";
export declare const PACKAGE_RESPONSIBILITY_FILE = "AGENTS.md";
/** Placeholder a header template uses for a credential the user supplies locally. */
export declare const CREDENTIAL_PLACEHOLDER: RegExp;
export declare const EXPERT_LIMITS: Readonly<{
    nameLength: 40;
    summaryLength: 200;
    responsibilityBytes: number;
    tags: 12;
    tagLength: 20;
    starterPrompts: 8;
    starterPromptLength: 200;
    categories: 3;
    skills: 20;
    skillBytes: number;
    tools: 30;
    customTools: 10;
    credentialSlots: 8;
    knowledge: 20;
    allowlist: 2000;
    ownerNameLength: 40;
    contactLength: 120;
    releaseNoteLength: 500;
    packageBytes: number;
    packageEntries: 64;
    catalogBytes: number;
    experts: 200;
    toolLibrary: 200;
}>;
export declare const EXPERT_ID_PATTERN: RegExp;
/** Local preset ids (custom experts are `<source>-custom-<hex>`, cloud experts `cloud-<id>`). */
export declare const PRESET_ID_PATTERN: RegExp;
export declare const SKILL_NAME_PATTERN: RegExp;
export declare const METRIC_KNOWLEDGE_ID_PATTERN: RegExp;
export declare const ONEBOX_SPACE_ID_PATTERN: RegExp;
export declare const SHARED_LIBRARY_ID_PATTERN: RegExp;
export declare const KNOWLEDGE_REF_PATTERN: RegExp;
export declare const EMPLOYEE_ID_PATTERN: RegExp;
export declare const CUSTOM_TOOL_KEY_PATTERN: RegExp;
export declare const CREDENTIAL_KEY_PATTERN: RegExp;
export declare const SERVER_NAME_PATTERN: RegExp;
export declare const HEADER_NAME_PATTERN: RegExp;
export declare const ENV_NAME_PATTERN: RegExp;
export declare const BUILTIN_TOOL_ID_PATTERN: RegExp;
export declare const SHA256_PATTERN: RegExp;
export declare const HEX_COLOR_PATTERN: RegExp;
/** A stdio command must be a program name the recipient's machine resolves, never a file path. */
export declare const PORTABLE_COMMAND_PATTERN: RegExp;
export declare const EXPERT_ICONS: readonly ["sparkles", "document", "megaphone", "design", "analytics", "briefcase", "research", "code", "shield"];
export type ExpertIcon = typeof EXPERT_ICONS[number];
export declare const BUILTIN_CAPABILITIES: readonly ["shell", "filesystem", "goal", "todo", "subagent"];
export type BuiltinCapability = typeof BUILTIN_CAPABILITIES[number];
export declare const BUILTIN_CAPABILITY_LABELS: Readonly<Record<BuiltinCapability, string>>;
/** Tool Market tools the product ships (stable ids). Custom MCP tools are distributed separately. */
export declare const BUILTIN_TOOLS: readonly [{
    readonly id: "webfetch";
    readonly name: "网页抓取";
}, {
    readonly id: "browser";
    readonly name: "浏览器操作";
}, {
    readonly id: "metric-query";
    readonly name: "指标查询";
}, {
    readonly id: "data-asset-query";
    readonly name: "数据资产查询";
}, {
    readonly id: "data-agent-tool";
    readonly name: "DataAgentConnector";
}, {
    readonly id: "welink";
    readonly name: "WeLink";
}, {
    readonly id: "operations-platform-auth";
    readonly name: "运营平台认证";
}];
export declare const BUILTIN_TOOL_IDS: ReadonlySet<string>;
/** The product's expert taxonomy (`experts/catalog.json`); a test keeps the two in step. */
export declare const EXPERT_CATEGORIES: readonly [{
    readonly id: "general";
    readonly name: "综合通用";
    readonly enabled: false;
}, {
    readonly id: "office-collaboration";
    readonly name: "办公协作";
    readonly enabled: false;
}, {
    readonly id: "content-growth";
    readonly name: "内容增长";
    readonly enabled: false;
}, {
    readonly id: "design-creation";
    readonly name: "设计创作";
    readonly enabled: false;
}, {
    readonly id: "data-insight";
    readonly name: "数据分析";
    readonly enabled: true;
}, {
    readonly id: "push";
    readonly name: "PUSH";
    readonly enabled: true;
}, {
    readonly id: "business-operations";
    readonly name: "商业经营";
    readonly enabled: false;
}, {
    readonly id: "knowledge-research";
    readonly name: "知识研究";
    readonly enabled: false;
}, {
    readonly id: "engineering-development";
    readonly name: "技术研发";
    readonly enabled: false;
}, {
    readonly id: "operations-security";
    readonly name: "运维安全";
    readonly enabled: false;
}, {
    readonly id: "marketing";
    readonly name: "营销";
    readonly enabled: true;
}, {
    readonly id: "editorial-office";
    readonly name: "总编室";
    readonly enabled: true;
}];
export declare const EXPERT_CATEGORY_IDS: ReadonlySet<string>;
/** Header names the MCP transport owns (same list as `@dsh-ops/tool-runtime`). */
export declare const RESERVED_HEADER_NAMES: ReadonlySet<string>;
/** Skill names other owners publish into every expert; a distributed Skill may not take them. */
export declare const RESERVED_SKILL_NAMES: ReadonlySet<string>;
export declare const RESERVED_SKILL_PREFIX = "knowledge-";
/** Whether a request header carries a secret (same rule as `@dsh-ops/tool-runtime`). */
export declare function isSensitiveHeaderName(name: string): boolean;
/** Lower-case, trimmed WeLink employee id, or `undefined` when the value is not one. */
export declare function normalizeEmployeeId(value: unknown): string | undefined;
export declare function presetIdForCloudExpert(id: string): string;
export declare function customToolIdForCloudTool(key: string): string;
export declare function packageSkillPath(name: string): string;
/** Characters below 0x20 other than tab, line feed and carriage return, plus DEL. */
export declare function hasControlCharacters(value: string, allowLineBreaks?: boolean): boolean;
export declare const EmployeeIdSchema: z.ZodString;
export declare const ExpertIdSchema: z.ZodString;
export declare const SkillNameSchema: z.ZodString;
export declare const BuiltinCapabilitySchema: z.ZodEnum<{
    shell: "shell";
    filesystem: "filesystem";
    goal: "goal";
    todo: "todo";
    subagent: "subagent";
}>;
export declare const AppearanceSchema: z.ZodObject<{
    icon: z.ZodEnum<{
        sparkles: "sparkles";
        document: "document";
        megaphone: "megaphone";
        design: "design";
        analytics: "analytics";
        briefcase: "briefcase";
        research: "research";
        code: "code";
        shield: "shield";
    }>;
    accent: z.ZodString;
    background: z.ZodString;
}, z.core.$strict>;
export type ExpertAppearance = z.infer<typeof AppearanceSchema>;
export declare const OwnerSchema: z.ZodObject<{
    name: z.ZodString;
    employeeId: z.ZodString;
    contact: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type ExpertOwner = z.infer<typeof OwnerSchema>;
export declare const BuiltinToolRefSchema: z.ZodObject<{
    toolId: z.ZodString;
    required: z.ZodBoolean;
}, z.core.$strict>;
export declare const CustomToolRefSchema: z.ZodObject<{
    customTool: z.ZodString;
    required: z.ZodBoolean;
}, z.core.$strict>;
export declare const ToolRefSchema: z.ZodUnion<readonly [z.ZodObject<{
    toolId: z.ZodString;
    required: z.ZodBoolean;
}, z.core.$strict>, z.ZodObject<{
    customTool: z.ZodString;
    required: z.ZodBoolean;
}, z.core.$strict>]>;
export type BuiltinToolRef = z.infer<typeof BuiltinToolRefSchema>;
export type CustomToolRef = z.infer<typeof CustomToolRefSchema>;
export type ToolRef = z.infer<typeof ToolRefSchema>;
export declare const MetricKnowledgeRefSchema: z.ZodObject<{
    kind: z.ZodLiteral<"metric">;
    knowledgeId: z.ZodString;
    name: z.ZodOptional<z.ZodString>;
    required: z.ZodBoolean;
}, z.core.$strict>;
export declare const OneboxKnowledgeRefSchema: z.ZodObject<{
    kind: z.ZodLiteral<"onebox">;
    ref: z.ZodString;
    name: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    spaceId: z.ZodOptional<z.ZodString>;
    sharedLibraryId: z.ZodOptional<z.ZodString>;
    required: z.ZodBoolean;
}, z.core.$strict>;
export declare const KnowledgeRefSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"metric">;
    knowledgeId: z.ZodString;
    name: z.ZodOptional<z.ZodString>;
    required: z.ZodBoolean;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"onebox">;
    ref: z.ZodString;
    name: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    spaceId: z.ZodOptional<z.ZodString>;
    sharedLibraryId: z.ZodOptional<z.ZodString>;
    required: z.ZodBoolean;
}, z.core.$strict>], "kind">;
export type MetricKnowledgeRef = z.infer<typeof MetricKnowledgeRefSchema>;
export type OneboxKnowledgeRef = z.infer<typeof OneboxKnowledgeRefSchema>;
export type KnowledgeRef = z.infer<typeof KnowledgeRefSchema>;
export declare const CredentialSlotSchema: z.ZodObject<{
    key: z.ZodString;
    label: z.ZodString;
    location: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"header">;
        name: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"env">;
        name: z.ZodString;
    }, z.core.$strict>], "kind">;
    hint: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type CredentialSlot = z.infer<typeof CredentialSlotSchema>;
declare const CustomToolShape: z.ZodObject<{
    key: z.ZodString;
    name: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    transport: z.ZodEnum<{
        stdio: "stdio";
        "streamable-http": "streamable-http";
    }>;
    serverName: z.ZodString;
    url: z.ZodOptional<z.ZodString>;
    headers: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
    command: z.ZodOptional<z.ZodString>;
    args: z.ZodDefault<z.ZodArray<z.ZodString>>;
    timeoutMs: z.ZodDefault<z.ZodNumber>;
    credentials: z.ZodDefault<z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        label: z.ZodString;
        location: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"header">;
            name: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"env">;
            name: z.ZodString;
        }, z.core.$strict>], "kind">;
        hint: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export interface PortabilityIssue {
    code: string;
    message: string;
    path: Array<string | number>;
    severity: 'error' | 'warning';
}
/**
 * Why a custom MCP tool definition cannot run on someone else's machine, or would carry a secret.
 * Errors block export, import and publishing; warnings are shown and let through.
 */
export declare function customToolPortabilityIssues(tool: z.input<typeof CustomToolShape>): PortabilityIssue[];
export declare const CustomToolDefinitionSchema: z.ZodObject<{
    key: z.ZodString;
    name: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    transport: z.ZodEnum<{
        stdio: "stdio";
        "streamable-http": "streamable-http";
    }>;
    serverName: z.ZodString;
    url: z.ZodOptional<z.ZodString>;
    headers: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
    command: z.ZodOptional<z.ZodString>;
    args: z.ZodDefault<z.ZodArray<z.ZodString>>;
    timeoutMs: z.ZodDefault<z.ZodNumber>;
    credentials: z.ZodDefault<z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        label: z.ZodString;
        location: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"header">;
            name: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"env">;
            name: z.ZodString;
        }, z.core.$strict>], "kind">;
        hint: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export type CustomToolDefinition = z.infer<typeof CustomToolDefinitionSchema>;
/** A cloud custom tool as the public catalog serves it: the definition plus its library revision. */
export declare const CloudCustomToolSchema: z.ZodObject<{
    key: z.ZodString;
    name: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    transport: z.ZodEnum<{
        stdio: "stdio";
        "streamable-http": "streamable-http";
    }>;
    serverName: z.ZodString;
    url: z.ZodOptional<z.ZodString>;
    headers: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
    command: z.ZodOptional<z.ZodString>;
    args: z.ZodDefault<z.ZodArray<z.ZodString>>;
    timeoutMs: z.ZodDefault<z.ZodNumber>;
    credentials: z.ZodDefault<z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        label: z.ZodString;
        location: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"header">;
            name: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"env">;
            name: z.ZodString;
        }, z.core.$strict>], "kind">;
        hint: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>>;
    revision: z.ZodString;
    updatedAt: z.ZodString;
}, z.core.$strict>;
export type CloudCustomTool = z.infer<typeof CloudCustomToolSchema>;
/** Byte-bounded, NUL-free Markdown responsibility (`AGENTS.md`). */
export declare function responsibilityIssue(value: string): string | undefined;
export declare const PackageSkillSchema: z.ZodObject<{
    name: z.ZodString;
    required: z.ZodBoolean;
    file: z.ZodString;
    sha256: z.ZodString;
    size: z.ZodNumber;
}, z.core.$strict>;
export type PackageSkill = z.infer<typeof PackageSkillSchema>;
/** `expert.json` inside an expert package. */
export declare const ExpertPackageDefinitionSchema: z.ZodObject<{
    name: z.ZodString;
    summary: z.ZodString;
    appearance: z.ZodObject<{
        icon: z.ZodEnum<{
            sparkles: "sparkles";
            document: "document";
            megaphone: "megaphone";
            design: "design";
            analytics: "analytics";
            briefcase: "briefcase";
            research: "research";
            code: "code";
            shield: "shield";
        }>;
        accent: z.ZodString;
        background: z.ZodString;
    }, z.core.$strict>;
    categoryIds: z.ZodArray<z.ZodString>;
    tags: z.ZodArray<z.ZodString>;
    starterPrompts: z.ZodArray<z.ZodString>;
    sortOrder: z.ZodOptional<z.ZodNumber>;
    builtinTools: z.ZodArray<z.ZodEnum<{
        shell: "shell";
        filesystem: "filesystem";
        goal: "goal";
        todo: "todo";
        subagent: "subagent";
    }>>;
    skills: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        required: z.ZodBoolean;
        file: z.ZodString;
        sha256: z.ZodString;
        size: z.ZodNumber;
    }, z.core.$strict>>;
    tools: z.ZodArray<z.ZodUnion<readonly [z.ZodObject<{
        toolId: z.ZodString;
        required: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        customTool: z.ZodString;
        required: z.ZodBoolean;
    }, z.core.$strict>]>>;
    customTools: z.ZodDefault<z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        name: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        transport: z.ZodEnum<{
            stdio: "stdio";
            "streamable-http": "streamable-http";
        }>;
        serverName: z.ZodString;
        url: z.ZodOptional<z.ZodString>;
        headers: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
        command: z.ZodOptional<z.ZodString>;
        args: z.ZodDefault<z.ZodArray<z.ZodString>>;
        timeoutMs: z.ZodDefault<z.ZodNumber>;
        credentials: z.ZodDefault<z.ZodArray<z.ZodObject<{
            key: z.ZodString;
            label: z.ZodString;
            location: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"header">;
                name: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"env">;
                name: z.ZodString;
            }, z.core.$strict>], "kind">;
            hint: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>>;
    }, z.core.$strict>>>;
    knowledge: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"metric">;
        knowledgeId: z.ZodString;
        name: z.ZodOptional<z.ZodString>;
        required: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"onebox">;
        ref: z.ZodString;
        name: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        spaceId: z.ZodOptional<z.ZodString>;
        sharedLibraryId: z.ZodOptional<z.ZodString>;
        required: z.ZodBoolean;
    }, z.core.$strict>], "kind">>;
    owner: z.ZodObject<{
        name: z.ZodString;
        employeeId: z.ZodString;
        contact: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    suggestedAllowlist: z.ZodOptional<z.ZodArray<z.ZodString>>;
    releaseNote: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type ExpertPackageDefinition = z.infer<typeof ExpertPackageDefinitionSchema>;
export declare const PackageFileSchema: z.ZodObject<{
    path: z.ZodString;
    size: z.ZodNumber;
    sha256: z.ZodString;
}, z.core.$strict>;
export declare const ExpertPackageManifestSchema: z.ZodObject<{
    format: z.ZodLiteral<"dsh-ops-expert-package">;
    schemaVersion: z.ZodLiteral<1>;
    exportedAt: z.ZodString;
    appVersion: z.ZodOptional<z.ZodString>;
    origin: z.ZodObject<{
        expertId: z.ZodString;
        employeeId: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    files: z.ZodArray<z.ZodObject<{
        path: z.ZodString;
        size: z.ZodNumber;
        sha256: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ExpertPackageManifest = z.infer<typeof ExpertPackageManifestSchema>;
export declare const CloudSkillSchema: z.ZodObject<{
    name: z.ZodString;
    sha256: z.ZodString;
    size: z.ZodNumber;
    kind: z.ZodEnum<{
        zip: "zip";
        md: "md";
    }>;
    required: z.ZodBoolean;
}, z.core.$strict>;
export type CloudSkill = z.infer<typeof CloudSkillSchema>;
/** One expert of the public catalog: its current published version plus distribution facts. */
export declare const CloudExpertSchema: z.ZodObject<{
    id: z.ZodString;
    presetId: z.ZodString;
    version: z.ZodNumber;
    publishedAt: z.ZodString;
    name: z.ZodString;
    summary: z.ZodString;
    appearance: z.ZodObject<{
        icon: z.ZodEnum<{
            sparkles: "sparkles";
            document: "document";
            megaphone: "megaphone";
            design: "design";
            analytics: "analytics";
            briefcase: "briefcase";
            research: "research";
            code: "code";
            shield: "shield";
        }>;
        accent: z.ZodString;
        background: z.ZodString;
    }, z.core.$strict>;
    categoryIds: z.ZodArray<z.ZodString>;
    tags: z.ZodArray<z.ZodString>;
    starterPrompts: z.ZodArray<z.ZodString>;
    sortOrder: z.ZodNumber;
    owner: z.ZodObject<{
        name: z.ZodString;
        employeeId: z.ZodString;
        contact: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    allowClone: z.ZodBoolean;
    builtinTools: z.ZodArray<z.ZodEnum<{
        shell: "shell";
        filesystem: "filesystem";
        goal: "goal";
        todo: "todo";
        subagent: "subagent";
    }>>;
    tools: z.ZodArray<z.ZodUnion<readonly [z.ZodObject<{
        toolId: z.ZodString;
        required: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        customTool: z.ZodString;
        required: z.ZodBoolean;
    }, z.core.$strict>]>>;
    knowledge: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"metric">;
        knowledgeId: z.ZodString;
        name: z.ZodOptional<z.ZodString>;
        required: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"onebox">;
        ref: z.ZodString;
        name: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        spaceId: z.ZodOptional<z.ZodString>;
        sharedLibraryId: z.ZodOptional<z.ZodString>;
        required: z.ZodBoolean;
    }, z.core.$strict>], "kind">>;
    skills: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        sha256: z.ZodString;
        size: z.ZodNumber;
        kind: z.ZodEnum<{
            zip: "zip";
            md: "md";
        }>;
        required: z.ZodBoolean;
    }, z.core.$strict>>;
    responsibility: z.ZodObject<{
        sha256: z.ZodString;
        size: z.ZodNumber;
    }, z.core.$strict>;
}, z.core.$strict>;
export type CloudExpert = z.infer<typeof CloudExpertSchema>;
export declare const CloudExpertCatalogEnvelopeSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    contractVersion: z.ZodLiteral<1>;
    generatedAt: z.ZodString;
    identity: z.ZodObject<{
        recognized: z.ZodBoolean;
    }, z.core.$strict>;
    experts: z.ZodArray<z.ZodUnknown>;
    customTools: z.ZodArray<z.ZodUnknown>;
}, z.core.$strict>;
export interface CloudExpertCatalog {
    schemaVersion: typeof CATALOG_SCHEMA_VERSION;
    contractVersion: typeof CONTRACT_VERSION;
    generatedAt: string;
    identity: {
        recognized: boolean;
    };
    experts: CloudExpert[];
    customTools: CloudCustomTool[];
}
export interface RejectedCatalogEntry {
    kind: 'expert' | 'customTool';
    id?: string;
    reason: string;
}
/**
 * Parse a catalog response. The envelope must be valid; a single malformed expert or tool is
 * dropped and reported instead of failing the whole catalog, and an expert whose custom tool was
 * dropped (or is missing) is dropped with it.
 */
export declare function parseCloudExpertCatalog(payload: unknown): {
    catalog: CloudExpertCatalog;
    rejected: RejectedCatalogEntry[];
};
export type ExpertVisibility = {
    mode: 'everyone';
} | {
    mode: 'allowlist';
    employeeIds: string[];
};
export declare const VisibilitySchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    mode: z.ZodLiteral<"everyone">;
}, z.core.$strict>, z.ZodObject<{
    mode: z.ZodLiteral<"allowlist">;
    employeeIds: z.ZodArray<z.ZodString>;
}, z.core.$strict>], "mode">;
/** Whether an employee sees an expert: published, on sale, and everyone / on the allowlist / the owner. */
export declare function isExpertVisible(expert: {
    status: 'active' | 'disabled';
    published: boolean;
    visibility: ExpertVisibility;
    owner: {
        employeeId: string;
    };
}, employeeId: string | undefined): boolean;
export declare const EXPERT_ROUTES: Readonly<{
    catalog: "/api/experts/v1/catalog";
    responsibility: (id: string, version: number) => string;
    skill: (id: string, version: number, name: string) => string;
}>;
export {};
//# sourceMappingURL=index.d.ts.map
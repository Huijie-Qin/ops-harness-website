/**
 * Turn whatever a user already has — a folder, a ZIP made by any tool, a working copy the
 * assistant edited — into Skill trees the publish pipeline accepts, fixing what can be fixed and
 * reporting only what cannot (ADR 0032 decision 7). Pure: no file system, no stores.
 *
 * Everything here used to be a refusal: a folder whose name differs from `name`, a wrapper
 * folder around the Skill, a template `SKILL.md` deeper in the tree, `description: Use when: …`
 * without quotes, a missing newline after the closing `---`, camelCase invocation keys, VCS and
 * dependency folders counted against the file limit. DSH itself only needs a root `SKILL.md`
 * with a valid `name` and a non-empty `description`.
 *
 * Every entry repairs with this one module (2026-10-16): the product's 我的技能 (save, import, online
 * editing, ZIP replace), the website's upload of one Skill, and the cloud install of a published one.
 * What it produces passes the distribution rules of `./tree`.
 */
export declare const SKILL_MANIFEST = "SKILL.md";
/** Bound the manifest the stores read back (personal-skill-store `MAX_MANIFEST_BYTES`). */
export declare const MAX_SKILL_MANIFEST_BYTES: number;
/** Runtime Skill name grammar shared with DSH (`dsh-skill` `SKILL_NAME`). */
export declare const SKILL_NAME_PATTERN: RegExp;
export declare const MAX_SKILL_NAME_LENGTH: 64;
export interface SkillTreeLimits {
    /** Files one Skill may carry after skipped folders are dropped. */
    maxFiles: number;
    /** Bytes one Skill may carry after skipped folders are dropped. */
    maxBytes: number;
    /** Bytes of a single file. */
    maxFileBytes: number;
}
export interface SkillTreeNote {
    code: string;
    message: string;
    path?: string;
}
export interface NormalizedSkill {
    /** Folder of the Skill inside the input, `''` when the input root is the Skill itself. */
    root: string;
    name: string;
    displayName: string;
    description: string;
    /** Files relative to the Skill root; `SKILL.md` already rewritten when a fix applied. */
    files: Map<string, Uint8Array>;
    fileCount: number;
    bytes: number;
    /** What was changed automatically; shown before the import is confirmed. */
    fixes: SkillTreeNote[];
    /** What blocks this Skill; an empty list means it can be published as is. */
    problems: SkillTreeNote[];
}
export interface NormalizedSkillTree {
    skills: NormalizedSkill[];
    /** Paths dropped as VCS, dependency, cache or product-owned files, with a count. */
    skipped: {
        count: number;
        examples: string[];
    };
    /** Files outside every Skill root. */
    ignored: string[];
    /** Problems of the input as a whole (nothing found, wrong folder). */
    problems: SkillTreeNote[];
}
export interface NormalizeOptions {
    limits: SkillTreeLimits;
    /**
     * Name to use for a Skill whose root is the input root and whose manifest has no usable
     * `name`: the chosen folder or the archive file name.
     */
    rootNameHint?: string;
    /**
     * What is never Skill content: dropped, not counted, and named in the skipped summary. Defaults to
     * the distribution rules' {@link isIgnoredSkillPath}; 我的技能 adds the markers its stores write.
     */
    skip?: SkipRule;
    /**
     * The Skill's name as a person gave it (the website's admin, after `name-required`): used as is, the
     * manifest's own `name` kept as the display name. Must be a runtime name.
     */
    name?: string;
    /**
     * Never make a name up: a manifest `name` that is neither usable once trimmed nor cleanable without
     * losing a letter (Chinese, emoji, none at all) is reported as `name-required` instead of being taken
     * from the folder or a hash. The website asks its admin then.
     */
    requireName?: boolean;
}
/** What a reader leaves out of a Skill, and how its skipped summary names one such path. */
export interface SkipRule {
    matches(relative: string): boolean;
    summary(relative: string): string;
}
/** The distribution rules: `isIgnoredSkillPath`, summarised by the ignored folder (`node_modules/`). */
export declare const DISTRIBUTION_SKIP_RULE: SkipRule;
/** A runtime-valid name derived from anything a person typed, or `''` when nothing usable remains. */
export declare function suggestSkillName(raw: string): string;
/**
 * {@link suggestSkillName} when it keeps every letter and digit of `raw` (only case, accents, spaces and
 * punctuation change: `Weekly_Report` → `weekly-report`), `''` when it would drop some: Chinese, emoji.
 */
export declare function suggestSkillNameWithoutLoss(raw: string): string;
export declare function isSkillName(value: string): boolean;
/**
 * Split a flat file map into Skills: every folder holding a `SKILL.md` that no outer folder
 * already claims is one Skill; deeper manifests are ordinary files of the outer Skill.
 */
export declare function normalizeSkillTree(input: ReadonlyMap<string, Uint8Array>, options: NormalizeOptions): NormalizedSkillTree;
//# sourceMappingURL=normalize.d.ts.map
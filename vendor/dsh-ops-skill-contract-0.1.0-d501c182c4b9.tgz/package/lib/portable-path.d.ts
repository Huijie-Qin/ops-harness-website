/** Validate and NFC-normalize one archive path using rules safe on every supported Host. */
export declare function validatePortableArchivePath(value: string, directory: boolean): string;
/** Validate and NFC-normalize one path segment against Windows and POSIX hazards. */
export declare function validatePortableArchiveSegment(segment: string): string;
/**
 * The nearest name `validatePortableArchiveSegment` accepts, for a file a person named on a system
 * that allows more: characters Windows reserves become `_`, trailing dots and spaces go, and a
 * device name gets `_` after its stem (`CON.md` → `CON_.md`).
 * @returns `undefined` for a segment no rename makes safe (`..`, `.`, empty, `__proto__`).
 */
export declare function usablePortableArchiveSegment(segment: string): string | undefined;
/**
 * Whether a file path the portable rules refuse becomes acceptable once each segment is renamed
 * with `usablePortableArchiveSegment`: relative, `/`-separated, not on a drive, and without a
 * segment no rename makes safe. An import keeps such a file for the normalizer to rename.
 */
export declare function isRenamablePortableArchivePath(value: string): boolean;
/** Return a deterministic Windows-style collision key for one archive path segment. */
export declare function portableArchiveCollisionKey(value: string): string;
//# sourceMappingURL=portable-path.d.ts.map
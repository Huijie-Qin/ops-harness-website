# @dsh-ops/skill-contract

技能的共享规则：产品（「我的技能」的四个入口、导出专家、安装云端专家）和官网（上传单个技能、导入专家包）用同一份代码。
官网以精确版本的 pnpm pack 制品离线消费（见官网 `vendor/README.md`），不另写一份。

只依赖 `yaml`（精确版本 2.9.0，与官网和产品其他包一致），不导入 DSH、Cordis 或 Host 插件。

## 两层

| 子路径 | 内容 | 谁用 |
| --- | --- | --- |
| `./tree`（无依赖） | 严格检查：`SKILL_TREE_LIMITS`、`skillTreeIssues`、`skillPathIssue`、`skillManifestIssues`、`isIgnoredSkillPath`、`isIgnoredSkillDirectory`、`LEGACY_CLIENT_LIMITS` / `legacyClientIssues` | 导出专家、官网导入专家包、官网上传单个技能（修好之后再查）、安装云端专家 |
| `./normalize` | 自动修复：`normalizeSkillTree`、`suggestSkillName`、`suggestSkillNameWithoutLoss`、`isSkillName` | 「我的技能」的对话保存、导入、在线编辑、用 ZIP 替换；官网上传单个技能；安装云端专家（只修 `SKILL.md`） |
| `./portable-path` | 跨平台文件名：`validatePortableArchivePath`、`usablePortableArchiveSegment`、`portableArchiveCollisionKey` 等 | 修复代码；「我的技能」的存储与日志 |

根入口导出全部三层。`@dsh-ops/expert-distribution-contract` 的 `./skill-tree` 转引 `./tree`，旧的引用方式照常可用。

## 规则要点

- **严格检查按 DSH 加载技能的方式判断（2026-10-16）。** DSH 读技能时名字一个字符都不修剪，遇到旧式开关键
  （`userInvocable`、`disableModelInvocation`、`modelInvocable`）或读不懂的开关值，会跳过整个技能，只在日志里留一条
  警告。因此 `skillManifestIssues` 收整段信息块：名字前后有空格或换行（例如 `name: |` 多行）报 `name-whitespace`；
  旧式开关键报 `invocation-legacy`；`user-invocable` / `disable-model-invocation` 不是 DSH 认的值（布尔、`1`/`0`、
  `true/yes/on/false/no/off`）报 `invocation-invalid`。各接收方读信息块时要把整段交进来。
- **修复只做能确定的事。** 写法不标准的 YAML、信息块分隔线、GBK / UTF-16 编码、不合规的名字、Windows 不能用的文件名
  与只差大小写的文件、YAML 锚点（展开成普通写法，因为接收方都不展开锚点）。修不了的（重复的键、缩进错乱、Latin-1
  编码、两个 `SKILL.md`）报成具体原因。修复产出的内容一定通过 `./tree` 的检查，`test/normalize.test.ts` 守住这一点。
- **修复的选项：**
  - `skip`：哪些文件不算技能内容。缺省是分发规则的 `isIgnoredSkillPath`；「我的技能」另外跳过自己存储写的标记文件。
  - `name`：按人填写的英文名起名，清单里原来的名字留作显示名（官网管理员在 `name-required` 之后填写）。
  - `requireName`：名字整理不出来时不自己凑。名字去掉首尾空白后合规就用，拼写能整理且一个字母都不丢就整理
    （`Weekly_Report` → `weekly-report`），否则报 `name-required`；不再取文件夹名或随机短码。官网与云端安装打开它，
    「我的技能」不打开（照旧用文件夹名兜底）。

## 版本

- 0.1.0（2026-10-16）：从专家分发契约的 `./skill-tree` 与 skill-market 的修复代码、跨平台文件名代码拆出，规则不变；
  同时补上上面三类 DSH 会静默跳过的写法，修复代码新增 `name`、`requireName`、`skip` 选项与 YAML 锚点展开。
  单独成包是为了不和专家分发契约的版本差（官网 0.2.4 与产品主线的 MCP 子工具配置）绑在一起：官网只多引入这一个制品。

# @dsh-ops/cloud-task-contract

产品 Host、官网控制面与云端执行器共用的"云端定时任务"协议。纯数据包：只有 zod 严格 schema、常量与路由表，不注册 Cordis 插件，不访问网络或文件系统。契约版本 `CONTRACT_VERSION = 1`。

三方分工：

- **产品 Host**（`@dsh-ops/cloud-tasks`）以用户访问令牌调用用户接口：提交/修改任务、读取运行记录、下载产物。
- **官网控制面**拥有任务定义与计划、运行队列、产物、令牌与实例状态；用户接口与执行器接口都在 `/api/cloud/v1` 下，见 `cloudRoutes`。
- **云端执行器**（`@dsh-ops/cloud-executor`，装在每个用户的云端实例里）以执行器令牌心跳、领取运行、上报进度与结果。

所有请求体与响应体都是 `.strict()` schema，未知字段直接拒绝，版本漂移会在两端立刻暴露。日期一律 ISO 8601 带时区。计划（`CloudSchedule`）与产品定时任务的 once / interval / calendar 三种形态保持一致（星期 1–7，周一为 1），不含 dynamic。

官网通过 `pnpm pack` 产物（`vendor/dsh-ops-cloud-task-contract-<版本>-<sha256 前 12 位>.tgz`）离线消费，来源与哈希记录在官网 `vendor/cloud-task-contract.json`；更新流程与 `release-contract` 相同：先改源包并递增版本，构建、打包、更新官网 `package.json` 与锁文件。不得覆盖同版本制品，不得在官网另维护一份协议实现。

运行时依赖：zod 4.4.3（MIT），无原生构建需求。

## 工作区会话历史（0.3.0）

`CloudTaskDefinition.workspaceId` 可选，省略仍兼容旧任务。`CloudRun.cloudWorkspaceId/cloudSessionId` 与 `CloudSession.source/runId/taskId/historyStatus` 将定时任务日志纳入统一会话历史；调度会话只读，取消仍通过 run。`ClaimedRun.workspace/session` 可选以兼容旧官网。官网 POST `/runs/:runId/session` 幂等打开历史，旧日志使用 `session.history` 命令按需冷读取；`historyStatus` 为 `not-loaded/loading/ready/unavailable`。旧执行器不会处理新增命令，官网和执行器需协调升级。`RunListQuery.search` 按名称/摘要文字匹配，`statuses` 接受非空枚举数组或 HTTP 逗号列表，省略为全部。

目录的可选 `capabilities` 由执行器 Tool Market 实际状态投影，包含 `tools`（id/name/added/availability/产品化 unavailableReason）与装配层明确声明的 `disabledTools`。不透传诊断文本、路径、登录身份或修复动作。`RunCompletion.historyComplete` 仅在具备历史的 claim 上发送；未完整确认的历史标为 unavailable，可通过 runSession 冷读取修复。

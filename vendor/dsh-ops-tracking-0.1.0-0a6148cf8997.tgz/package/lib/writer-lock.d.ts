/** Publish a complete owner record atomically; never overwrite a live writer. */
export declare function acquireWriterLock(root: string): Promise<() => Promise<void>>;
//# sourceMappingURL=writer-lock.d.ts.map
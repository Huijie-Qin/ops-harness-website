import { type VerifiedIdentitySnapshot } from './contracts.js';
export interface TrackingIdentityProvider {
    snapshot(): VerifiedIdentitySnapshot | null;
    subscribe(onChanged: () => void): () => void;
}
/** Host-only provider. Tokens never enter this interface or the event spool. */
export declare class TrackingIdentity {
    private installationId;
    private now;
    private current;
    constructor(installationId: string, now?: () => number);
    set(snapshot: unknown): void;
    snapshot(): VerifiedIdentitySnapshot | null;
    attach(provider: TrackingIdentityProvider): () => void;
}
//# sourceMappingURL=identity-provider.d.ts.map
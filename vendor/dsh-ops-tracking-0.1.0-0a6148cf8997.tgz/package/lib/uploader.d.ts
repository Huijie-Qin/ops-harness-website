import { type TrackingEvent } from './contracts.js';
import type { EventSpool } from './event-file.js';
export declare function collectionOrigin(value: string): string;
export declare class TrackingUploader {
    private spool;
    private origin;
    private environment;
    private interval;
    private fetcher;
    private timer;
    private busy;
    private inFlight;
    private stopped;
    private failures;
    private lastWritten;
    private unsubscribe;
    private limit;
    private controller;
    readonly health: {
        state: string;
        lastUploadAt: string;
        error: string;
    };
    constructor(spool: EventSpool, origin: string, environment: TrackingEvent['environment'], interval?: number, fetcher?: typeof fetch);
    start(): void;
    private schedule;
    flush(): Promise<void>;
    private performFlush;
    stop(): Promise<void>;
}
export declare function boundedText(response: Response, limit: number): Promise<string>;
//# sourceMappingURL=uploader.d.ts.map
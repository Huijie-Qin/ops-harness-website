import type { Context } from '@deepseek-ai/cordis';
import type { Session, SessionEvent } from '@deepseek-ai/dsh-session';
import type { TrackingService } from './service.js';
/** Public append feed only. No history replay, message text, tool output or filesystem reads. */
export declare class SessionTrackingObserver {
    private tracking;
    private states;
    constructor(tracking: TrackingService);
    private id;
    private unknownActor;
    observe(session: Session): void;
    private properties;
    private emit;
    private usage;
    consume(session: Session, event: SessionEvent): void;
    forget(session: Session): void;
    dispose(): void;
}
export declare function attachSessionTracking(ctx: Context, tracking: TrackingService): void;
//# sourceMappingURL=session-observer.d.ts.map
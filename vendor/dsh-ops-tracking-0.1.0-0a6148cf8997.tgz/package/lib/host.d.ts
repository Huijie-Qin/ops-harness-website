import type { Action, InstantEvent, TrackingEvent, Outcome } from './contracts.js';
import type { z } from 'zod';
export type TrackOptions = {
    initiator?: TrackingEvent['initiator'];
    interactionId?: string;
    operationId?: string;
    eventId?: string;
    occurredAt?: string;
};
export type FinishResult = {
    outcome: z.infer<typeof Outcome>;
    changed?: boolean;
    errorCode?: TrackingEvent['errorCode'];
};
export type CapturedOperation = {
    action: Action;
    properties: Record<string, unknown>;
    accepted: TrackingEvent;
};
export interface Operation {
    finish(result: FinishResult): void;
    capture(): CapturedOperation | null;
}
export interface ModuleTracker {
    track(name: InstantEvent, properties?: Record<string, unknown>, options?: TrackOptions): {
        queued: boolean;
    };
    startOperation(action: Action, properties?: Record<string, unknown>, options?: TrackOptions): Operation;
    resumeOperation(captured: CapturedOperation | null): Operation;
}
export interface TrackingHost {
    forModule(module: string): ModuleTracker;
}
export declare const noopOperation: Operation;
export declare function getTracker(ctx: object, module: string): ModuleTracker;
/** Only wrap explicit business boundaries; validation belongs before this call. */
export declare function trackOperation<T>(tracker: ModuleTracker, action: Action, properties: Record<string, unknown>, run: () => Promise<T>, result?: (value: T) => FinishResult, options?: TrackOptions): Promise<T>;
//# sourceMappingURL=host.d.ts.map
import { type TrackingEvent, type VerifiedIdentitySnapshot } from './contracts.js';
import { TrackingIdentity, type TrackingIdentityProvider } from './identity-provider.js';
import { type ModuleTracker } from './host.js';
import type { EventSpool } from './event-file.js';
export declare class TrackingService {
    readonly spool: EventSpool;
    readonly config: {
        environment: TrackingEvent['environment'];
        appVersion: string;
    };
    private now;
    private sequence;
    private runtimeId;
    readonly identity: TrackingIdentity;
    private identityDispose;
    private alive;
    constructor(spool: EventSpool, config: {
        environment: TrackingEvent['environment'];
        appVersion: string;
    }, now?: () => number);
    registerIdentityProvider(provider: TrackingIdentityProvider): () => void;
    /** Internal observer context: never reassign an in-flight turn to a later login. */
    captureModule(module: string): ModuleTracker;
    forModule(module: string, capturedIdentity?: VerifiedIdentitySnapshot | null): ModuleTracker;
    private event;
    private emit;
    private operation;
    dispose(): void;
}
//# sourceMappingURL=service.d.ts.map
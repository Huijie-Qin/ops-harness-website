import { z } from 'zod';
export declare const CATALOG_VERSION = 2;
export declare const MAX_EVENT_BYTES = 8192;
export declare const MAX_BATCH_BYTES = 262144;
export declare const Id: z.ZodString;
export declare const Environment: z.ZodEnum<{
    production: "production";
    development: "development";
    test: "test";
}>;
export declare const Initiator: z.ZodEnum<{
    user: "user";
    agent: "agent";
    scheduler: "scheduler";
    system: "system";
    unknown: "unknown";
}>;
export declare const Outcome: z.ZodEnum<{
    unknown: "unknown";
    succeeded: "succeeded";
    failed: "failed";
    cancelled: "cancelled";
    partial: "partial";
}>;
export declare const ACTIONS: {
    readonly 'tool.add': "tools";
    readonly 'tool.remove': "tools";
    readonly 'tool.config.save': "tools";
    readonly 'tool.connection.test': "tools";
    readonly 'tool.invoke': "tools";
    readonly 'skill.install': "skills";
    readonly 'skill.update': "skills";
    readonly 'skill.uninstall': "skills";
    readonly 'skill.source.import': "skills";
    readonly 'skill.source.save': "skills";
    readonly 'skill.source.delete': "skills";
    readonly 'knowledge.add': "knowledge";
    readonly 'knowledge.remove': "knowledge";
    readonly 'knowledge.bind': "knowledge";
    readonly 'knowledge.unbind': "knowledge";
    readonly 'knowledge.import': "knowledge";
    readonly 'knowledge.update': "knowledge";
    readonly 'knowledge.delete': "knowledge";
    readonly 'knowledge.query': "knowledge";
    readonly 'expert.use': "experts";
    readonly 'expert.create': "experts";
    readonly 'expert.clone': "experts";
    readonly 'expert.update': "experts";
    readonly 'expert.delete': "experts";
    readonly 'creation.generate': "creation";
    readonly 'creation.publish': "creation";
    readonly 'creation.export': "creation";
    readonly 'task.create': "tasks";
    readonly 'task.update': "tasks";
    readonly 'task.pause': "tasks";
    readonly 'task.resume': "tasks";
    readonly 'task.delete': "tasks";
    readonly 'task.run': "tasks";
    readonly 'todo.refresh': "todos";
    readonly 'todo.suggestion.open': "todos";
};
export type Action = keyof typeof ACTIONS;
export declare const ActionSchema: z.ZodEnum<{
    "tool.add": "tool.add";
    "tool.remove": "tool.remove";
    "tool.config.save": "tool.config.save";
    "tool.connection.test": "tool.connection.test";
    "tool.invoke": "tool.invoke";
    "skill.install": "skill.install";
    "skill.update": "skill.update";
    "skill.uninstall": "skill.uninstall";
    "skill.source.import": "skill.source.import";
    "skill.source.save": "skill.source.save";
    "skill.source.delete": "skill.source.delete";
    "knowledge.add": "knowledge.add";
    "knowledge.remove": "knowledge.remove";
    "knowledge.bind": "knowledge.bind";
    "knowledge.unbind": "knowledge.unbind";
    "knowledge.import": "knowledge.import";
    "knowledge.update": "knowledge.update";
    "knowledge.delete": "knowledge.delete";
    "knowledge.query": "knowledge.query";
    "expert.use": "expert.use";
    "expert.create": "expert.create";
    "expert.clone": "expert.clone";
    "expert.update": "expert.update";
    "expert.delete": "expert.delete";
    "creation.generate": "creation.generate";
    "creation.publish": "creation.publish";
    "creation.export": "creation.export";
    "task.create": "task.create";
    "task.update": "task.update";
    "task.pause": "task.pause";
    "task.resume": "task.resume";
    "task.delete": "task.delete";
    "task.run": "task.run";
    "todo.refresh": "todo.refresh";
    "todo.suggestion.open": "todo.suggestion.open";
}>;
export declare const PageProperties: z.ZodObject<{
    pageKey: z.ZodEnum<{
        "my-todos": "my-todos";
        "skill-market": "skill-market";
        "knowledge-center": "knowledge-center";
        "tool-market": "tool-market";
        "expert-market": "expert-market";
        "scheduled-tasks": "scheduled-tasks";
        conversation: "conversation";
    }>;
}, z.core.$strict>;
export declare const SkillName: z.ZodString;
export declare const MessageProperties: z.ZodObject<{
    conversationId: z.ZodString;
    turn: z.ZodNumber;
    sessionKind: z.ZodEnum<{
        root: "root";
        subagent: "subagent";
    }>;
}, z.core.$strict>;
export declare const UsageProperties: z.ZodObject<{
    conversationId: z.ZodString;
    turn: z.ZodNumber;
    sessionKind: z.ZodEnum<{
        root: "root";
        subagent: "subagent";
    }>;
    step: z.ZodNumber;
    provider: z.ZodString;
    model: z.ZodString;
    usageReported: z.ZodBoolean;
    inputTokens: z.ZodNumber;
    outputTokens: z.ZodNumber;
    cacheReadTokens: z.ZodNumber;
    cacheWriteTokens: z.ZodNumber;
    reasoningTokens: z.ZodNumber;
}, z.core.$strict>;
export declare const SkillProperties: z.ZodObject<{
    conversationId: z.ZodString;
    turn: z.ZodNumber;
    sessionKind: z.ZodEnum<{
        root: "root";
        subagent: "subagent";
    }>;
    step: z.ZodNumber;
    skillName: z.ZodString;
    method: z.ZodEnum<{
        model: "model";
        explicit: "explicit";
    }>;
    result: z.ZodEnum<{
        succeeded: "succeeded";
        failed: "failed";
    }>;
}, z.core.$strict>;
export declare const InstantName: z.ZodEnum<{
    "page.view": "page.view";
    "feature.view": "feature.view";
    "auth.login.succeeded": "auth.login.succeeded";
    "auth.logout": "auth.logout";
    "conversation.message.accepted": "conversation.message.accepted";
    "conversation.model.usage": "conversation.model.usage";
    "skill.load.completed": "skill.load.completed";
}>;
export type InstantEvent = z.infer<typeof InstantName>;
export declare function propertiesSchema(event: string, action?: Action): z.ZodUnion<readonly [z.ZodObject<{
    conversationId: z.ZodString;
    turn: z.ZodNumber;
    sessionKind: z.ZodEnum<{
        root: "root";
        subagent: "subagent";
    }>;
}, z.core.$strict>, z.ZodObject<{}, z.core.$strict>]> | z.ZodObject<{}, z.core.$strict>;
export declare function featureFor(event: string, action?: Action, properties?: Record<string, unknown>): string;
export declare const EventSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    eventVersion: z.ZodLiteral<1>;
    eventId: z.ZodString;
    eventName: z.ZodEnum<{
        "page.view": "page.view";
        "feature.view": "feature.view";
        "auth.login.succeeded": "auth.login.succeeded";
        "auth.logout": "auth.logout";
        "conversation.message.accepted": "conversation.message.accepted";
        "conversation.model.usage": "conversation.model.usage";
        "skill.load.completed": "skill.load.completed";
        "operation.accepted": "operation.accepted";
        "operation.finished": "operation.finished";
    }>;
    module: z.ZodString;
    feature: z.ZodString;
    action: z.ZodOptional<z.ZodEnum<{
        "tool.add": "tool.add";
        "tool.remove": "tool.remove";
        "tool.config.save": "tool.config.save";
        "tool.connection.test": "tool.connection.test";
        "tool.invoke": "tool.invoke";
        "skill.install": "skill.install";
        "skill.update": "skill.update";
        "skill.uninstall": "skill.uninstall";
        "skill.source.import": "skill.source.import";
        "skill.source.save": "skill.source.save";
        "skill.source.delete": "skill.source.delete";
        "knowledge.add": "knowledge.add";
        "knowledge.remove": "knowledge.remove";
        "knowledge.bind": "knowledge.bind";
        "knowledge.unbind": "knowledge.unbind";
        "knowledge.import": "knowledge.import";
        "knowledge.update": "knowledge.update";
        "knowledge.delete": "knowledge.delete";
        "knowledge.query": "knowledge.query";
        "expert.use": "expert.use";
        "expert.create": "expert.create";
        "expert.clone": "expert.clone";
        "expert.update": "expert.update";
        "expert.delete": "expert.delete";
        "creation.generate": "creation.generate";
        "creation.publish": "creation.publish";
        "creation.export": "creation.export";
        "task.create": "task.create";
        "task.update": "task.update";
        "task.pause": "task.pause";
        "task.resume": "task.resume";
        "task.delete": "task.delete";
        "task.run": "task.run";
        "todo.refresh": "todo.refresh";
        "todo.suggestion.open": "todo.suggestion.open";
    }>>;
    occurredAt: z.ZodISODateTime;
    installationId: z.ZodUUID;
    runtimeId: z.ZodUUID;
    sequence: z.ZodNumber;
    identityRef: z.ZodOptional<z.ZodUUID>;
    initiator: z.ZodEnum<{
        user: "user";
        agent: "agent";
        scheduler: "scheduler";
        system: "system";
        unknown: "unknown";
    }>;
    interactionId: z.ZodOptional<z.ZodString>;
    operationId: z.ZodOptional<z.ZodString>;
    outcome: z.ZodOptional<z.ZodEnum<{
        unknown: "unknown";
        succeeded: "succeeded";
        failed: "failed";
        cancelled: "cancelled";
        partial: "partial";
    }>>;
    changed: z.ZodOptional<z.ZodBoolean>;
    durationMs: z.ZodOptional<z.ZodNumber>;
    errorCode: z.ZodOptional<z.ZodEnum<{
        unknown: "unknown";
        cancelled: "cancelled";
        partial: "partial";
        "operation-failed": "operation-failed";
    }>>;
    platform: z.ZodEnum<{
        darwin: "darwin";
        win32: "win32";
        linux: "linux";
        other: "other";
    }>;
    appVersion: z.ZodString;
    environment: z.ZodEnum<{
        production: "production";
        development: "development";
        test: "test";
    }>;
    properties: z.ZodRecord<z.ZodString, z.ZodUnknown>;
}, z.core.$strict>;
export type TrackingEvent = z.infer<typeof EventSchema>;
export declare const BatchSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    installationId: z.ZodUUID;
    environment: z.ZodEnum<{
        production: "production";
        development: "development";
        test: "test";
    }>;
    events: z.ZodArray<z.ZodUnknown>;
}, z.core.$strict>;
export declare const BatchResponseSchema: z.ZodObject<{
    acceptedIds: z.ZodArray<z.ZodString>;
    duplicateIds: z.ZodArray<z.ZodString>;
    rejected: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        code: z.ZodString;
        retryable: z.ZodBoolean;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type BatchResponse = z.infer<typeof BatchResponseSchema>;
export declare const IdentitySnapshotSchema: z.ZodObject<{
    identityRef: z.ZodUUID;
    installationId: z.ZodUUID;
    validFrom: z.ZodISODateTime;
    expiresAt: z.ZodISODateTime;
}, z.core.$strict>;
export type VerifiedIdentitySnapshot = z.infer<typeof IdentitySnapshotSchema>;
export declare const ClientEventSchema: z.ZodObject<{
    clientEventId: z.ZodUUID;
    module: z.ZodLiteral<"workbench">;
    eventName: z.ZodLiteral<"page.view">;
    properties: z.ZodObject<{
        pageKey: z.ZodEnum<{
            "my-todos": "my-todos";
            "skill-market": "skill-market";
            "knowledge-center": "knowledge-center";
            "tool-market": "tool-market";
            "expert-market": "expert-market";
            "scheduled-tasks": "scheduled-tasks";
            conversation: "conversation";
        }>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare function isActive(e: TrackingEvent): boolean;
export declare function isSuccess(e: TrackingEvent): boolean;
//# sourceMappingURL=contracts.d.ts.map
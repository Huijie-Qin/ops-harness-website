# @dsh-ops/tracking

## 对话与 Skill 自动采集

Host 可选订阅 `@deepseek-ai/dsh-session` 的公开事件，无需给每个会话 UI/业务模块重复打点。

- `conversation.message.accepted`：实际进入步骤的官方 Web 人工消息；区分消息次数与去重会话数。仅 `user + rpcId + clientTimeZone` 的根会话消息识别为人工，其他入口保留 unknown。
- `conversation.model.usage`：步骤结束后一次输出最新 usage；流式与最终消息不重复相加。总 Token = inputTokens（未缓存输入）+ cacheReadTokens + cacheWriteTokens + outputTokens；reasoningTokens 是输出子集。缺失用量标记 usageReported=false，不用估算值代替。
- `skill.load.completed`：公开 `skill-invocation` 指令注入为显式加载；官方 `skill` call/result 为模型加载。按 runtime manifest name 聚合成功/失败、显式/模型次数；同名不同版本/来源暂合并。

人工消息驱动活跃，后台步骤与子代理不增加人工次数。子代理在可关联父回合时继承其身份快照；没有可信公司身份仍为匿名。切号不改写旧回合，快照过期后的事件转为未归属。会话摘要键只用于去重，不上传消息/标题/Skill 正文、工具输出或文件路径。不重放历史、分叉种子或补扫旧会话。崩溃时未结束步骤用量可能丢失，辅助模型请求与隐藏重试不保证覆盖，保持运营级尽力采集。

官网提供对话与 Token、Skill 使用视图，用户明细包含对应指标，事实保留 400 天；按事件去重。协议目录版本为 2，批次/信封 schemaVersion 仍为 1，保留旧版消息事件兼容。

独立运营打点包，Cordis 插件 `ops-tracking`，Host Service `ctx.opsTracking`。源码目录为 `packages/shared/logger-tracking`。保持 DSH、Desktop、官网的普通 logger 和 `.log` 实现。

## 业务接入

在 package.json 的 dependencies 声明 `"@dsh-ops/tracking": "workspace:*"`，在插件 apply 内获取模块入口：

```ts
import { getTracker, trackOperation } from '@dsh-ops/tracking/host'
const tracker = getTracker(ctx, 'my-module')
// 先完成请求参数校验，再在拥有业务结果的入口调用。
return trackOperation(tracker, 'tool.add', { toolId }, async () => {
  return await enableAndPersist(toolId, signal)
}, value => ({ outcome: 'succeeded', changed: value.changed }))
```

`getTracker` 使用 Cordis 的受管理 `ctx.inject(['opsTracking'], …)` 子作用域等待服务，父业务插件不等待。DSH 使用的 Cordis 4 **不支持** `{ required, optional }` 注入声明；不得照搬其他版本。关闭/卸载打点不会停用业务。helper 按 Context/module 缓存；调用不等待磁盘或网络，失败不改变业务返回。

事件与操作 action/属性必须在 `src/contracts.ts` 注册白名单。不传用户 ID、姓名、正文、路径、Cookie、Token、原始异常。`initiator` 默认 unknown；只有已确认的人工作业入口设置 user。`trackOperation` 用于明确的短操作，默认人工；系统入口须显式覆盖。返回业务 `{ok:false}`、partial、无变更等时必须提供结果映射，不能依靠 HTTP/RPC 成功判定。

长任务使用 `startOperation().capture()`，把不含凭据的上下文保存在任务所有者的既有持久任务中，完成时 `resumeOperation(context).finish(...)`；不保存正文或认证凭据。相同 operationId 的完成事件 ID 稳定。没有可靠终态的中断任务保留 pending/unknown，不推断成功。

页面调用使用 `@dsh-ops/tracking/client` 的 `createClientTracker(connection)`，构建期内联；只接受 workbench 的 page.view 白名单。文件和网络仅在 Host。RPC `/ops-tracking` 是 loopback：`track` 接收 UI 事件，`health` 返回无凭据的本地采集状态。

## 身份接入（后续）

公司 SSO 验证与多来源绑定暂不实现。当前开发事件不带身份快照，以 installationId 标记安装实例，保持匿名；它不能代替员工账号或计入登录人数、DAU/MAU、用户排名。

保留 `registerIdentityProvider({snapshot, subscribe})` 作为后续消费认证侧已验证快照的接口，同一时刻只允许一个 provider；注册 disposer 归认证模块 effect 管理。快照含官网签发的 identityRef、安装 ID、有效区间，业务模块仍不传用户信息。切换账号时清除旧身份；操作在开始时固定身份，不把匿名历史追归登录者。现有 WeLink 名称及运营平台会话有效状态不会被当作公司主账号。当前未提供网络身份登记客户端，website 的 identity-sessions 返回未配置。

## 配置与文件

开发启动 `pnpm local:start` 使用 web Profile 和仓库 `.runtime/dsh-home`；开发 overlay 已配置：

```yaml
- id: ops-tracking
  config:
    enabled: true
    environment: development
    collectionOrigin: http://127.0.0.1:4173
```

在相邻 website 仓库执行 `pnpm dev`，本地配置 `trackingDevelopment: true`。上传两端都不需要 Token 或任何 tracking 凭据环境变量。官网管理员登录仍沿用原配置；后台默认展示开发环境数据，手动选择的环境会作为浏览器偏好保留。更换端口时同步修改 collectionOrigin。

development/test 仅向 loopback origin 上传，HTTP 或 HTTPS 均可。批次显式携带安装 ID 和原始环境，服务端固定开发 tenant 并逐条校验，重启不会把历史环境改为当前环境。未配置地址时只写文件；production 的上传和认证后续实现，当前健康状态为 production-upload-pending，保留日志，不发送请求。Bundle 与开发 overlay 均显式配置 `collectionOrigin: http://127.0.0.1:4173`；Bundle 环境仍为 production，本地 overlay 覆盖为 development 后启用开发上传。

`appVersion` 默认 0.1.0，发布时应同步实际产品版本。

数据位于 `$DSH_HOME/ops-tracking`：installation.json、events/operations.log（当前写入）、events/operations-yymmdd-hhmmss.log（轮转归档）、state/checkpoint.json。每行一个严格校验的 JSON 事件，扩展名 `.log`。单文件默认 20 MiB，目录默认 256 MiB，内存队列 2 MiB；先 fsync，再允许读取上传。每 30 秒或新落盘 100 条触发，一批最多 100 条/256 KiB，10 秒超时，失败退避，响应丢失重发原事件 ID。仅连续确认位置可前移；永久拒收保存安全诊断后跳过。

轮转使用 [rotating-file-stream](https://github.com/iccicci/rotating-file-stream) 精确版本 3.2.10（MIT，无运行依赖/原生构建）。每条完整写入后达到大小阈值，由框架重命名并新建 `operations.log`；归档名用本机时间，同秒冲突追加 `-2`、`-3`。未满活动文件重启续写，不按启动次数或时间切分；上限最多超出一条记录。保留逐行 JSON 和 `.log` 扩展名。

checkpoint v2 将确认偏移绑定文件身份（设备/inode/创建时间/首条记录 SHA-256），轮转过程中已发出的请求可正常确认；写入、读批次和确认提交串行执行。自动迁移旧 checkpoint v1，旧 UUID 文件继续补传/保留，不清空历史。复制恢复的文件保守重放，由服务端去重。框架不自动清理文件；打点模块只清理已确认的关闭文件。

已确认关闭的段最多保留 7 天，配额紧张时可提前清理；拒收诊断和截断尾副本保留 7 天。未确认数据不为新事件腾空间。写入失败或达到配额会丢弃新事件并标记降级，释放配额后重启恢复写入。尽力采集，业务事务和打点不是同一个事务；进程崩溃可能丢失未落盘队列。

正常退出释放独占锁；重启验证文件尾，截断的尾部先保留到 state。正常崩溃锁在同主机确认原 PID 已退出后自动回收；PID 仍存活、其他主机或恢复进程本身遗留锁时失败关闭。中段损坏、非法 checkpoint 不自动删除数据，停传并报告，需要维护人员保留文件并修复。不得在活动 Runtime 上手动删除锁。日志目录不在帮助页默认普通日志导出路径内。

## 验证

```sh
pnpm --filter @dsh-ops/tracking build
pnpm --filter @dsh-ops/tracking typecheck
pnpm --filter @dsh-ops/tracking test
```

官网通过本包纯 `contracts` 导出使用精确 vendor tarball；该入口不加载 DSH、Cordis 或文件系统。SSO、部署与覆盖清单见仓库 `docs/runbooks/operation-tracking.md`。

/** Build-time browser adapter; no credentials, actor claims or business outcomes. */
export function createClientTracker(connection, module = 'workbench') {
  return { track(eventName, properties) {
    const bytes = crypto.getRandomValues(new Uint8Array(16))
    bytes[6] = (bytes[6] & 15) | 64; bytes[8] = (bytes[8] & 63) | 128
    const hex = Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('')
    const clientEventId = `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`
    void connection.rpc.call('/ops-tracking', 'track', { clientEventId, module, eventName, properties }, AbortSignal.timeout(3000)).catch(() => {})
  } }
}
